#!/usr/bin/env python

import sys
import csv
import re
import random
import numpy as np
import matplotlib.pyplot as plt

#empty_list/dic_for_randomized_sampling
month_site_dic = {}
row_list = []
temp_list = []
sampled_site_list_TSE_n_Stream = []
y_data_for_kind_of_provinces_TSE_n_Stream = []
x_data_for_detection_score_TSE_n_Stream = []

#sampling_months_and_those_sampling_sites
y1_TSE_n_Stream = ('TSE_n_Stream', '2014-03', '2014-04', '2014-05', '2014-07', '2014-08', '2014-09', '2014-10',
                   '2015-01', '2015-02')
y2_TSE_n_Stream = ('TSE_n_Stream', '2015-03')
y3_TSE_n_Stream = ('TSE_n_Stream', '2015-05')
y4_TSE_n_Stream = ('TSE_n_Stream', '2015-07', '2015-09', '2015-12')
y5_TSE_n_Stream = ('TSE_n_Stream', '2016-01')
y6_TSE_n_Stream = ('TSE_n_Stream', '2016-02')
y7_TSE_n_Stream = ('TSE_n_Stream', '2016-03')
y8_TSE_n_Stream = ('TSE_n_Stream', '2016-05')
y9_TSE_n_Stream = ('TSE_n_Stream', '2017-10', '2017-11', '2017-12', '2018-02', '2018-04')
month_site_dic[y1_TSE_n_Stream] = ['DL01', 'EL01', 'EL02', 'EL03', 'EL04', 'EL05', 'EL06', 'FL01', 'FL02', 'FL03',
                                   'FL04', 'FL05', 'FL06', 'GL01', 'GL02', 'GL03', 'GL04', 'GL05', 'GL06']
month_site_dic[y2_TSE_n_Stream] = ['DL01A', 'DL01B', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A', 'EL03B',
                                   'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D',
                                   'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02',
                                   'GL02A', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C', 'GL07', 'DE',
                                   'EE', 'FE', 'GE']
month_site_dic[y3_TSE_n_Stream] = ['DL01A', 'DL01C', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A', 'EL03B',
                                   'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D',
                                   'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02',
                                   'GL02A', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C', 'GL07', 'DE',
                                   'EE', 'FE', 'GE']
month_site_dic[y4_TSE_n_Stream] = ['DL01A', 'DL01C', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03',
                                   'EL03A', 'EL03B', 'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B',
                                   'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A',
                                   'GL01B', 'GL02', 'GL02A', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C',
                                   'GL07', 'DE', 'EE', 'FE', 'GE']
month_site_dic[y5_TSE_n_Stream] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03',
                                   'EL03A', 'EL03B', 'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B',
                                   'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A',
                                   'GL01B', 'GL02', 'GL02A', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C',
                                   'GL07', 'DE', 'EE', 'FE', 'GE']
month_site_dic[y6_TSE_n_Stream] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D',
                                   'EL02E', 'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL03A', 'EL03B', 'EL06', 'EL06A',
                                   'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A',
                                   'FL04B', 'FL07', 'FL07A', 'FL07B', 'FL08', 'FL08A', 'FL08B', 'FL08C', 'FL08D',
                                   'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A', 'GL02A1', 'GL02B', 'GL02C', 'GL06',
                                   'GL06A', 'GL06B', 'GL06C', 'GL06D', 'GL06E', 'GL08', 'GL08A', 'GL08B', 'GL07',
                                   'DE', 'EE', 'FE', 'GE']
month_site_dic[y7_TSE_n_Stream] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D',
                                   'EL02E', 'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL06', 'EL06A', 'EL07', 'EL07A',
                                   'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL04B', 'FL07',
                                   'FL07A', 'FL07B', 'FL08', 'FL08A', 'FL08B', 'FL08C', 'FL08D', 'GL01', 'GL01A',
                                   'GL01B', 'GL02', 'GL02A', 'GL02A1', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B',
                                   'GL06C', 'GL06D', 'GL06E', 'GL08', 'GL08A', 'GL08B', 'GL07', 'DE', 'EE', 'FE', 'GE']
month_site_dic[y8_TSE_n_Stream] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D',
                                   'EL02E', 'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL06', 'EL06A', 'EL07', 'EL07A',
                                   'EL08', 'EL09', 'EL09A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04',
                                   'FL04A', 'FL07', 'FL07A', 'FL07B', 'FL08', 'FL08A', 'FL08B', 'FL08C', 'FL08D',
                                   'GL01', 'GL02', 'GL02A', 'GL02A1', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B',
                                   'GL06C', 'GL06D', 'GL06E', 'GL08', 'GL08A', 'GL08B', 'GL07', 'DE', 'EE', 'FE', 'GE']
month_site_dic[y9_TSE_n_Stream] = ['AM', 'AS', 'DL02', 'FL01B', 'MW', 'AME', 'ASE', 'DE', 'FE', 'MWE']

#regionC_lineages
GII_genotype = ['GII.1', 'GII.2a', 'GII.2b', 'GII.2c', 'GII.3b', 'GII.3c', 'GII.4s', 'GII.4ns',
                'GII.5', 'GII.6a', 'GII.6b', 'GII.6c', 'GII.8', 'GII.9', 'GII.12', 'GII.13', 'GII.14',
                'GII.17o', 'GII.17n', 'GII.21', 'GII.25']

with open('seqs_GII_rc_2014-2018.csv', 'rb') as csv_in_file1:
    filereader = csv.reader(csv_in_file1)
    for row in filereader:
        row_list.append(row)
    for n, genotype in enumerate(GII_genotype):
        y_data_for_kind_of_provinces_TSE_n_Stream.append(genotype + '_y_provinces')
        x_data_for_detection_score_TSE_n_Stream.append(genotype + '_x_sites')
        # _y_provinces=total_number_of_sampled_positive_provinces
        # _x_sites=total_number_of_sampled_positive_sites
        for repeat_index in range(1, 1001):
            if genotype == row_list[0][6 + n].replace('\t', ''):
                for row1 in row_list:
                    complement_number = 20 - len(row1)
                    while complement_number > 0:
                        row1.append('-')
                        complement_number = complement_number - 1
                    if row1[6 + n] == 'positive':
                        if row1[1][:7] in y1_TSE_n_Stream:
                            if row1[4] in month_site_dic[y1_TSE_n_Stream]:
                                for element in month_site_dic[y1_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y2_TSE_n_Stream:
                            if row1[4] in month_site_dic[y2_TSE_n_Stream]:
                                for element in month_site_dic[y2_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y3_TSE_n_Stream:
                            if row1[4] in month_site_dic[y3_TSE_n_Stream]:
                                for element in month_site_dic[y3_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y4_TSE_n_Stream:
                            if row1[4] in month_site_dic[y4_TSE_n_Stream]:
                                for element in month_site_dic[y4_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y5_TSE_n_Stream:
                            if row1[4] in month_site_dic[y5_TSE_n_Stream]:
                                for element in month_site_dic[y5_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y6_TSE_n_Stream:
                            if row1[4] in month_site_dic[y6_TSE_n_Stream]:
                                for element in month_site_dic[y6_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y7_TSE_n_Stream:
                            if row1[4] in month_site_dic[y7_TSE_n_Stream]:
                                for element in month_site_dic[y7_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y8_TSE_n_Stream:
                            if row1[4] in month_site_dic[y8_TSE_n_Stream]:
                                for element in month_site_dic[y8_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        if row1[1][:7] in y9_TSE_n_Stream:
                            if row1[4] in month_site_dic[y9_TSE_n_Stream]:
                                for element in month_site_dic[y9_TSE_n_Stream]:
                                    if re.findall(row1[4][0], element[0]):
                                        temp_list.append(element)
                                if len(temp_list) == 1:
                                    if re.findall('M', temp_list[0][0]):
                                        sampled_site_list_TSE_n_Stream.append('E')
                                    else:
                                        sampled_site_list_TSE_n_Stream.append(temp_list[0])
                                else:
                                    samples = random.sample(temp_list, 1)
                                    if row1[4] == samples[0]:
                                        if re.findall('M', samples[0][0]):
                                            sampled_site_list_TSE_n_Stream.append('E')
                                        else:
                                            sampled_site_list_TSE_n_Stream.append(samples[0])
                                temp_list = []
                            else:
                                pass
                        else:
                            continue
                    else:
                        continue
            y_data_for_kind_of_provinces_TSE_n_Stream.append(len(list(set([s[:1] for s in sampled_site_list_TSE_n_Stream]))))
            x_data_for_detection_score_TSE_n_Stream.append(len(sampled_site_list_TSE_n_Stream))
            sampled_site_list_TSE_n_Stream = []

        with open('GII_random_sampling_data.csv', 'ab') as csv_out_file2:
            #preparation_of_randomized_sampling_data_in_a_csv_file
            csv_filewriter2 = csv.writer(csv_out_file2)
            csv_filewriter2.writerow(x_data_for_detection_score_TSE_n_Stream)
            csv_filewriter2.writerow(y_data_for_kind_of_provinces_TSE_n_Stream)
            csv_out_file2.close()
        y_data_for_kind_of_provinces_TSE_n_Stream = []
        x_data_for_detection_score_TSE_n_Stream = []

#empty_list_for_describe_scatter_plot
row_list2 = []
x_coordinate_mean_value = []
y_coordinate_mean_value = []
order_for_parental_lineages = []
order_for_Hparental_lineages = []
order_for_Lparental_lineages = []
P_x_coordinate_mean_value = []
P_y_coordinate_mean_value = []
HP_x_coordinate_mean_value = []
HP_y_coordinate_mean_value = []
LP_x_coordinate_mean_value = []
LP_y_coordinate_mean_value = []
NP_x_coordinate_mean_value = []
NP_y_coordinate_mean_value = []
NHP_x_coordinate_mean_value = []
NHP_y_coordinate_mean_value = []

#regionC_lineages
HP = ['GII.17n', 'GII.4ns', 'GII.4s', 'GII.6b', 'GII.2a']
LP = ['GII.13', 'GII.2b', 'GII.17o', 'GII.8', 'GII.6c']
GII_genotype = ['GII.17n', 'GII.21', 'GII.4ns', 'GII.4s', 'GII.6b', 'GII.13', 'GII.1', 'GII.2a', 'GII.5',
                'GII.3b', 'GII.2b', 'GII.17o', 'GII.6a', 'GII.12', 'GII.8', 'GII.2c', 'GII.14', 'GII.9',
                'GII.3c', 'GII.22', 'GII.6c', 'GII.25']

#parsing_of_randomized_sampling_data
with open('GII_random_sampling_data.csv', 'rb') as csv_in_file:
    filereader2 = csv.reader(csv_in_file)
    for r in filereader2:
        row_list2.append(r)
    for lineage in GII_genotype:
        for row2 in row_list2:
            if lineage == row2[0].replace('_x_sites', ''):
                x_coordinate_mean_value.append(round((sum(float(a) for a in row2[1:])/(len(row2)-1)), 3))
            if lineage == row2[0].replace('_y_provinces', ''):
                y_coordinate_mean_value.append(round((sum(float(a) for a in row2[1:])/(len(row2)-1)), 3))
for n, lineage in enumerate(GII_genotype):
    for p in HP:
        if lineage == p:
            order_for_Hparental_lineages.append(n)
    for pp in LP:
        if lineage == pp:
            order_for_Lparental_lineages.append(n)
for nn, x_c in enumerate(x_coordinate_mean_value):
    if nn not in order_for_Hparental_lineages:
        NHP_x_coordinate_mean_value.append(x_coordinate_mean_value[nn])
        if nn not in order_for_Lparental_lineages:
            NP_x_coordinate_mean_value.append(x_coordinate_mean_value[nn])
        elif nn in order_for_Lparental_lineages:
            LP_x_coordinate_mean_value.append(x_coordinate_mean_value[nn])
    elif nn in order_for_Hparental_lineages:
        HP_x_coordinate_mean_value.append(x_coordinate_mean_value[nn])
    else:
        print('error')
        break
for nn, y_c in enumerate(y_coordinate_mean_value):
    if nn not in order_for_Hparental_lineages:
        NHP_y_coordinate_mean_value.append(y_coordinate_mean_value[nn])
        if nn not in order_for_Lparental_lineages:
            NP_y_coordinate_mean_value.append(y_coordinate_mean_value[nn])
        elif nn in order_for_Lparental_lineages:
            LP_y_coordinate_mean_value.append(y_coordinate_mean_value[nn])
    elif nn in order_for_Hparental_lineages:
        HP_y_coordinate_mean_value.append(y_coordinate_mean_value[nn])
    else:
        print('error')
        break

#scatter_plot
plt.figure()
plt.scatter(HP_x_coordinate_mean_value, HP_y_coordinate_mean_value, marker='o', edgecolor='red', color='red', s=20)
plt.scatter(LP_x_coordinate_mean_value, LP_y_coordinate_mean_value, marker='o', edgecolor='blue', color='blue', s=20)
plt.xlim(-1, max(x_coordinate_mean_value) + 1)
plt.ylim(-1, max(y_coordinate_mean_value) + 1)
plt.xticks([0, 5, 10, 15, 20, 25], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 1, 2, 3, 4, 5], fontsize=15, fontweight='bold', fontname='Arial')
plt.xlabel('Mean values of positive sampling sites, 2014-2018', fontsize=15, fontweight='bold', fontname='Arial')
plt.ylabel('Mean values of positive provinces, 2014-2018', fontsize=15, fontweight='bold', fontname='Arial')
plt.savefig('fig7b.png', dpi=200)

#scatter_plot_with_lineage_name
plt.figure()
plt.scatter(HP_x_coordinate_mean_value, HP_y_coordinate_mean_value, marker='o', edgecolor='red', color='red', s=20)
plt.scatter(LP_x_coordinate_mean_value, LP_y_coordinate_mean_value, marker='o', edgecolor='blue', color='blue', s=20)
for i, txt in enumerate(HP):
    plt.annotate(txt, (HP_x_coordinate_mean_value[i], HP_y_coordinate_mean_value[i]),
                 xytext=(HP_x_coordinate_mean_value[i],
                         HP_y_coordinate_mean_value[i]), color='red')
for i, txt in enumerate(LP):
    plt.annotate(txt, (LP_x_coordinate_mean_value[i], LP_y_coordinate_mean_value[i]),
                 xytext=(LP_x_coordinate_mean_value[i],
                         LP_y_coordinate_mean_value[i]), color='blue')
plt.xlim(-1, max(x_coordinate_mean_value) + 1)
plt.ylim(-1, max(y_coordinate_mean_value) + 1)
plt.xticks([0, 5, 10, 15, 20, 25], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 1, 2, 3, 4, 5], fontsize=15, fontweight='bold', fontname='Arial')
plt.xlabel('Mean values of positive sampling sites, 2014-2018', fontsize=15, fontweight='bold', fontname='Arial')
plt.ylabel('Mean values of positive provinces, 2014-2018', fontsize=15, fontweight='bold', fontname='Arial')
plt.show()