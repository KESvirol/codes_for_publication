[Overview]
This readme file provides instructions for Python scripts that were used in a published paper(PMID: 33187997).
Four Python scripts were prepared, which were used to present plots central to the main subject of the paper. 
Python scripts contain command-lines for parsing one of the two csv files that are included in the zip file.
The two csv files include geographical and seasonal information of isolated region C amplicon of both norovirus genogroupI (GI) and genogroupII (GII).
Among four scripts, two are for plots of GI and two are for those of GII.
The scripts are covered by the "Python License (Python-2.0)"



[System requirements]
- Hardware requirements
Python scripts require a current standard computer system.

- Software requirements
Python scripts have been tested on following systems:
Windows 7 professional (64 bit)
Python version (3.6.3) for Windows,

- Module requirements for Python script
csv
re
random
numpy
matplotlib



[Installation guide]
For the installation of python, please follow the instructions on the web-page (https://wiki.python.org/moin/BeginnersGuide/Download)
In the installation process, please check "Add Python 3.x to PATH".
Typical install time : 30 min

To read or edit Python scripts, please install PyCharm community for Windows "https://www.jetbrains.com/pycharm/download/#section=windows"

The message "ModuleNotFoundError" in the "Windows PowerShell" after running Python scripts means that one or more of the modules need to be installed.
For the installation of modules, plesase see "https://docs.python.org/3/installing/index.html"



[Demo]
Example data are real data that are used in the published manuscript
Expected output from four python scripts: 
(i) Eighteen figure files (*.png; fig4a, fig4b, fig4c, fig4d, fig4e, fig4f, fig4g, fig4h, fig6a, fig6b, fig6c, fig6d, fig6e, fig6f, fig6g, fig7a, and fig7b)
(ii) Six csv files (*.csv; Fig.4_raw_data. Fig.6_raw_data, GI_box_plot_data_for_MW_U_test_2017-2018, GII_box_plot_data_for_MW_U_test_2014-2018, GI_random_sampling_data, and GII_random_sampling_data)

Run time in a tested computer [Intel Xeon E3-1535M v5 2.90Ghz, 32GB RAM]:
Fig_4.py (3.8 s), Fig_6.py (2.5 s), Fig_7a.py (3.1 s), and Fig_7b.py (35.7 s)

Expected run time in a normal computer: 
Fig_4.py, Fig_6.py, and Fig_7a.py (less than 30 s each),
Fig_7b.py (less than 1 min)



[Instructions for use]
- Unzip the zipfile into appropriate location in your hard drive 
- Run standard program "Windows power shell" in Windows 7
- Enter unzipped folder using the "Windows power shell"
- Input command: 
python Fig.4.py
python Fig.6.py
python Fig.7a.py
python Fig.7b.py
or
py Fig.4.py
py Fig.6.py
py Fig.7a.py
py Fig.7b.py
