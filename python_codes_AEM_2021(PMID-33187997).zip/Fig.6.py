#!/usr/bin/env python

import sys
import csv
import re
import matplotlib.pyplot as plt

regionC_csv_file_name = ['seqs_GI_rc_2017-2018.csv']

#patterns_and_empty lists/dictionaries
pattern_sample = re.compile('(\d\d\d\d\d\d\d\d_\D+\w+_)')
pattern_clone_number = re.compile('(_\d\d_)')
pattern_GI_genotype = re.compile('(GI.\S+)')
pattern_GI_rdrp = re.compile('(GI.P\S+_)')
row_list_GI = []
row_list_GI2 = []
sample_name_list = []
temporary_list = []
temporary_list_for_sum_parental_lineages = []
sample_detected_genotype_dic = {}
temporary_list_rc = []
y_value_lineage_rc = []
x_ticks_rc = []
lineage_positive_dic_rc = {}
list_for_total_co_isolated_number_in_identical_sample = []
list_for_diversity_of_co_isolated_lineages_in_identical_sample = []
P_diff_list1 = []
P_diff_list2 = []
P_diff_list_E1_E2 = []
S_diff_list1 = []
S_diff_list2 = []
S_diff_list_E1_E2 = []
order_for_color = []
p_detection_number = []
non_p_detection_number = []
p_total_co_isolated_seq = []
non_p_total_co_isolated_seq = []
p_diversity_of_co_isolated_lineage = []
non_p_diversity_of_co_isolated_lineage = []
order_for_non_parent = []
hp_detection_number = []
hp_order_for_color = []
hp_total_co_isolated_seq = []
hp_diversity_of_co_isolated_lineage = []
Lp_detection_number = []
Lp_order_for_color = []
Lp_total_co_isolated_seq = []
Lp_diversity_of_co_isolated_lineage = []
Nhp_detection_number = []
Nhp_order_for_color = []
Nhp_total_co_isolated_seq = []
Nhp_diversity_of_co_isolated_lineage = []

#parsing_of_csv_dataset
with open(regionC_csv_file_name[0], 'rb') as csv_in_file1:
    filereader1 = csv.reader(csv_in_file1)
    first_row = next(filereader1)
    for row1 in filereader1:
        row_list_GI.append(row1)
with open(regionC_csv_file_name[0], 'rb') as csv_in_file2:
    filereader2 = csv.reader(csv_in_file2)
    for row2 in filereader2:
        row_list_GI2.append(row2)
    lineages_rc = row_list_GI2[0][6:26]
    for n, Lineage_rc in enumerate(lineages_rc):
        a_rc = Lineage_rc.replace('\t', '')
        for row3 in row_list_GI2:
            if row3[6 + n] == 'positive':
                temporary_list_rc.append('positive')
            else:
                continue
        lineage_positive_dic_rc[a_rc] = temporary_list_rc
        temporary_list_rc = []
    for a_rc2 in lineage_positive_dic_rc.keys():
        y_value_lineage_rc.append(len(lineage_positive_dic_rc[a_rc2]))
        x_ticks_rc.append(a_rc2)

#bar_plot_for_detection_frequency
plt.figure()
def number(t):
    return(t[1])
zip_lineage_x_y_rc = zip(x_ticks_rc, y_value_lineage_rc)
zip_lineage_x_y_rc.sort(key=number, reverse=True)
new_x_ticks_rc = [x for x, num in zip_lineage_x_y_rc]
new_y_ticks_rc = [num for x, num in zip_lineage_x_y_rc]
plt.xlim(-1, len(x_ticks_rc) + 1)
plt.bar(new_x_ticks_rc, new_y_ticks_rc, tick_label=new_x_ticks_rc, align='center', edgecolor='black')
plt.xticks(fontsize=9, fontweight='bold', fontname='Arial', rotation=45)
plt.yticks(fontsize=9, fontweight='bold', fontname='Arial')
plt.xlabel('\n\nRegion C lineages of GI, 2017-2018', fontsize=12, fontweight='bold', fontname='Arial')
plt.ylabel('Detection frequency', fontsize=10, fontweight='bold', fontname='Arial')
plt.ylim(0, 25)
plt.savefig('fig6a.png', dpi=200)

#lists_for_both_scatter_plots_and_bubble_plot
x_tick_number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
y_tick_number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
x_tick_name = ['GI.1b', 'GI.5b', 'GI.2', 'GI.5a2', 'GI.5a1', 'GI.7c', 'GI.6a', 'GI.4b', 'GI.4a', 'GI.3b2', 'GI.3c',
               'GI.3a', 'GI.3d', 'GI.1a', 'GI.9', 'GI.NA', 'GI.3b1', 'GI.6b', 'GI.7a', 'GI.7b']
high_occurrence_parental_lineages = ['GI.1b', 'GI.5a1', 'GI.7c', 'GI.6a']
low_occurrence_parental_lineages = ['GI.4b', 'GI.4a', 'GI.3d', 'GI.1a', 'GI.7a']
non_high_occurrence_parental_lineages = ['GI.5b', 'GI.2', 'GI.5a2', 'GI.4b', 'GI.4a', 'GI.3b2', 'GI.3c', 'GI.3a',
                                         'GI.3d', 'GI.1a', 'GI.9', 'GI.NA', 'GI.3b1', 'GI.6b', 'GI.7a', 'GI.7b']
parental_lineages = ['GI.1b', 'GI.5a1', 'GI.7c', 'GI.6a', 'GI.4b', 'GI.4a', 'GI.3d', 'GI.1a', 'GI.7a']
non_parental_lineages = ['GI.5b', 'GI.2', 'GI.5a2', 'GI.3b2', 'GI.3c', 'GI.3a', 'GI.9', 'GI.NA', 'GI.3b1', 'GI.6b',
                         'GI.7b']
x_tick_name_sum = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []]
bubble_size = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []]
x_columns = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []]
y_coordinate_GI7b = [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
y_coordinate_GI7a = [19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19]
y_coordinate_GI6b = [18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18]
y_coordinate_GI3b1 = [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
y_coordinate_GINA = [16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16]
y_coordinate_GI9 = [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]
y_coordinate_GI1a = [14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14]
y_coordinate_GI3d = [13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13]
y_coordinate_GI3a = [12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12]
y_coordinate_GI3c = [11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11]
y_coordinate_GI3b2 = [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
y_coordinate_GI4a = [9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9]
y_coordinate_GI4b = [8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8]
y_coordinate_GI6a = [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7]
y_coordinate_GI7c = [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]
y_coordinate_GI5a1 = [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]
y_coordinate_GI5a2 = [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]
y_coordinate_GI2 = [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
y_coordinate_GI5b = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
y_coordinate_GI1b = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

#preparation_of_co-isolation_data
for r in row_list_GI:
    sample_name_list.append(re.sub(pattern_clone_number, '', re.findall(pattern_sample, r[0])[0]))
list_set_row_list_GI = list(set(sample_name_list))
for rr in list_set_row_list_GI:
    for r in row_list_GI:
        if rr == re.sub(pattern_clone_number, '', re.findall(pattern_sample, r[0])[0]):
            temporary_list.append(re.sub(pattern_GI_rdrp, '', re.findall(pattern_GI_genotype, r[0])[0]))
    sample_detected_genotype_dic[rr] = temporary_list
    temporary_list = []
for sample_name in sample_detected_genotype_dic.keys():
    for n, lineage1 in enumerate(new_x_ticks_rc):
        if lineage1 in list(set(sample_detected_genotype_dic[sample_name])):
            for element1 in list(set(sample_detected_genotype_dic[sample_name])):
                if lineage1 == element1:
                    continue
                else:
                    x_tick_name_sum[n].append(element1)
with open('Fig.6_raw_data.csv', 'ab') as csv_out_file1:
    first_row = ['Parental_group\t',
                 'Subject_lineage\t',
                 'Co-isolated_lineage\t',
                 'Co-isolated_cases\t']
    csv_filewriter1 = csv.writer(csv_out_file1)
    csv_filewriter1.writerow(first_row)
    csv_write_list = []

for ii, p in enumerate(x_tick_name_sum):
    list_for_total_co_isolated_number_in_identical_sample.append(len(p))
    list_for_diversity_of_co_isolated_lineages_in_identical_sample.append(len(list(set(p))))
    for nn, lineage in enumerate(new_x_ticks_rc):
        with open('Fig.6_raw_data.csv', 'ab') as csv_out_file1:
            csv_write_list = []
            if lineage not in p:
                bubble_size[nn].append(0)
            else:
                bubble_size[nn].append(p.count(lineage))
                if new_x_ticks_rc[ii] in high_occurrence_parental_lineages:
                    csv_write_list.append('HP')
                elif new_x_ticks_rc[ii] in low_occurrence_parental_lineages:
                    csv_write_list.append('LP')
                elif new_x_ticks_rc[ii] in non_parental_lineages:
                    csv_write_list.append('NP')
                else:
                    print('error')
                    break
                csv_write_list.append(new_x_ticks_rc[ii])
                csv_write_list.append(lineage)
                csv_write_list.append(p.count(lineage))
                csv_filewriter1 = csv.writer(csv_out_file1)
                csv_filewriter1.writerow(csv_write_list)
                csv_write_list = []

for h_parent in high_occurrence_parental_lineages:
    for lineage_n_detection_number in zip_lineage_x_y_rc:
        if h_parent == lineage_n_detection_number[0]:
            hp_detection_number.append(lineage_n_detection_number[1])
for nn, lineage in enumerate(new_x_ticks_rc):
    for h_parent in high_occurrence_parental_lineages:
        if lineage == h_parent:
            hp_order_for_color.append(nn)
for L_parent in low_occurrence_parental_lineages:
    for lineage_n_detection_number in zip_lineage_x_y_rc:
        if L_parent == lineage_n_detection_number[0]:
            Lp_detection_number.append(lineage_n_detection_number[1])
for nn, lineage in enumerate(new_x_ticks_rc):
    for L_parent in low_occurrence_parental_lineages:
        if lineage == L_parent:
            Lp_order_for_color.append(nn)
for Nh_parent in non_high_occurrence_parental_lineages:
    for lineage_n_detection_number in zip_lineage_x_y_rc:
        if Nh_parent == lineage_n_detection_number[0]:
            Nhp_detection_number.append(lineage_n_detection_number[1])
for nn, lineage in enumerate(new_x_ticks_rc):
    for Nh_parent in non_high_occurrence_parental_lineages:
        if lineage == Nh_parent:
            Nhp_order_for_color.append(nn)
for parent in parental_lineages:
    for lineage_n_detection_number in zip_lineage_x_y_rc:
        if parent == lineage_n_detection_number[0]:
            p_detection_number.append(lineage_n_detection_number[1])
for nn, lineage in enumerate(new_x_ticks_rc):
    for parent in parental_lineages:
        if lineage == parent:
            order_for_color.append(nn)
for nn, lineage in enumerate(new_x_ticks_rc):
    for non_parent in non_parental_lineages:
        if lineage == non_parent:
            order_for_non_parent.append(nn)
for non_parent in non_parental_lineages:
    for lineage_n_detection_number in zip_lineage_x_y_rc:
        if non_parent == lineage_n_detection_number[0]:
            non_p_detection_number.append(lineage_n_detection_number[1])
for n in order_for_color:
    p_total_co_isolated_seq.append(list_for_total_co_isolated_number_in_identical_sample[n])
    p_diversity_of_co_isolated_lineage.append(list_for_diversity_of_co_isolated_lineages_in_identical_sample[n])
for n in hp_order_for_color:
    hp_total_co_isolated_seq.append(list_for_total_co_isolated_number_in_identical_sample[n])
    hp_diversity_of_co_isolated_lineage.append(list_for_diversity_of_co_isolated_lineages_in_identical_sample[n])
for n in Lp_order_for_color:
    Lp_total_co_isolated_seq.append(list_for_total_co_isolated_number_in_identical_sample[n])
    Lp_diversity_of_co_isolated_lineage.append(list_for_diversity_of_co_isolated_lineages_in_identical_sample[n])
for n in Nhp_order_for_color:
    Nhp_total_co_isolated_seq.append(list_for_total_co_isolated_number_in_identical_sample[n])
    Nhp_diversity_of_co_isolated_lineage.append(list_for_diversity_of_co_isolated_lineages_in_identical_sample[n])
for n in order_for_non_parent:
    non_p_total_co_isolated_seq.append(list_for_total_co_isolated_number_in_identical_sample[n])
    non_p_diversity_of_co_isolated_lineage.append(list_for_diversity_of_co_isolated_lineages_in_identical_sample[n])
tup_list_for_a_lineage_occurrence_vs_total_co_isolated_number_in_identical_sample = \
    zip(new_y_ticks_rc, list_for_total_co_isolated_number_in_identical_sample)
tup_list_for_a_lineage_occurrence_vs_diversity_of_co_isolated_lineages_in_identical_sample = \
    zip(new_y_ticks_rc, list_for_diversity_of_co_isolated_lineages_in_identical_sample)
aver_y_ticks_a_lineage_occurrence = sum(new_y_ticks_rc) / len(new_y_ticks_rc)
aver_y_ticks_total_co_isolation = \
    sum(list_for_total_co_isolated_number_in_identical_sample) \
    / len(list_for_total_co_isolated_number_in_identical_sample)
aver_y_ticks_diversity_co_isolation = \
    sum(list_for_diversity_of_co_isolated_lineages_in_identical_sample) \
    / len(list_for_diversity_of_co_isolated_lineages_in_identical_sample)

#scatter_plot1
plt.figure()
for element1 in tup_list_for_a_lineage_occurrence_vs_total_co_isolated_number_in_identical_sample:
    P_diff_list1.append(element1[0] - aver_y_ticks_a_lineage_occurrence)
    P_diff_list2.append(element1[1] - aver_y_ticks_total_co_isolation)
    P_diff_list_E1_E2.append\
        ((element1[0] - aver_y_ticks_a_lineage_occurrence)*(element1[1] - aver_y_ticks_total_co_isolation))
P_correlation_coefficient = sum(P_diff_list_E1_E2) \
                            / (((sum(k**2 for k in P_diff_list1))**0.5) * ((sum(k**2 for k in P_diff_list2))**0.5))
plt.scatter(non_p_detection_number, non_p_total_co_isolated_seq, marker='x', color='black', alpha='1', s=75)
plt.scatter(p_detection_number, p_total_co_isolated_seq, marker='o', color='blue', alpha='1', s=30)
plt.scatter(hp_detection_number, hp_total_co_isolated_seq, marker='o', color='red', alpha='1', s=30)
plt.xlabel('Detection frequency, 2017-2018', fontsize=13, fontweight='bold', fontname='Arial')
plt.ylabel('Total number of co-isolated cases', fontsize=15, fontweight='bold', fontname='Arial')
plt.text(1, 40, 'PCC={}'.format(round(P_correlation_coefficient, 3)), fontweight='bold', fontname='Arial', fontsize=13)
plt.xticks([0, 5, 10, 15, 20], fontsize=12, fontweight='bold', fontname='Arial')
plt.yticks([0, 15, 30, 45], fontsize=12, fontweight='bold', fontname='Arial')
plt.xlim(0, 21)
plt.savefig('fig6b.png', dpi=200)

#scatter_plot2
plt.figure()
P_diff_list1 = []
P_diff_list2 = []
P_diff_list_E1_E2 = []
for element2 in tup_list_for_a_lineage_occurrence_vs_diversity_of_co_isolated_lineages_in_identical_sample:
    P_diff_list1.append(element2[0] - aver_y_ticks_a_lineage_occurrence)
    P_diff_list2.append(element2[1] - aver_y_ticks_diversity_co_isolation)
    P_diff_list_E1_E2.append\
        ((element2[0] - aver_y_ticks_a_lineage_occurrence)*(element2[1] - aver_y_ticks_diversity_co_isolation))
P_correlation_coefficient = sum(P_diff_list_E1_E2) \
                            / (((sum(k**2 for k in P_diff_list1))**0.5) * ((sum(k**2 for k in P_diff_list2))**0.5))
plt.scatter(non_p_detection_number, non_p_diversity_of_co_isolated_lineage, marker='x', color='black', alpha='1', s=75)
plt.scatter(p_detection_number, p_diversity_of_co_isolated_lineage, marker='o', color='blue', alpha='1', s=30)
plt.scatter(hp_detection_number, hp_diversity_of_co_isolated_lineage, marker='o', color='red', alpha='1', s=30)
plt.xlabel('Detection frequency, 2017-2018', fontsize=13, fontweight='bold', fontname='Arial')
plt.ylabel('Total number of types of\nco-isolated region C lineages',
           fontsize=15, fontweight='bold', fontname='Arial')
plt.text(1, 13, 'PCC={}'.format(round(P_correlation_coefficient, 3)), fontweight='bold', fontname='Arial', fontsize=13)
plt.xticks([0, 5, 10, 15, 20], fontsize=12, fontweight='bold', fontname='Arial')
plt.yticks([0, 5, 10, 15], fontsize=12, fontweight='bold', fontname='Arial')
plt.savefig('fig6c.png', dpi=200)

#bubble_plot1
plt.figure()
plt.scatter(x_tick_number, y_coordinate_GI1b, s=bubble_size[0], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI5b, s=bubble_size[1], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI2, s=bubble_size[2], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI5a2, s=bubble_size[3], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI5a1, s=bubble_size[4], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI7c, s=bubble_size[5], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI6a, s=bubble_size[6], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI4b, s=bubble_size[7], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI4a, s=bubble_size[8], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI3b2, s=bubble_size[9], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI3c, s=bubble_size[10], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI3a, s=bubble_size[11], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI3d, s=bubble_size[12], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI1a, s=bubble_size[13], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI9, s=bubble_size[14], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GINA, s=bubble_size[15], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI3b1, s=bubble_size[16], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI6b, s=bubble_size[17], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI7a, s=bubble_size[18], color='dimgray')
plt.scatter(x_tick_number, y_coordinate_GI7b, s=bubble_size[19], color='dimgray')
plt.xticks([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
           [x_name for x_number, x_name in zip(x_tick_number, new_x_ticks_rc)],
           fontsize=7, fontweight='bold', rotation=90, fontname='Arial')
plt.yticks([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
           [name for y_number, name in zip(y_tick_number, new_x_ticks_rc)],
           fontsize=7, fontweight='bold', fontname='Arial')
plt.xlabel('Region C lineages of GI, 2017-2018', fontsize=10, fontweight='bold', fontname='Arial')
plt.ylabel('Co-isolated region C lineages\nin identical samples', fontsize=10, fontweight='bold', fontname='Arial')
plt.xlim(0, 21)
plt.ylim(0, 21)
plt.savefig('fig6d.png', dpi=200)

#bubble_plot2
plt.figure()
whole_x_tick_number = x_tick_number + x_tick_number + x_tick_number + x_tick_number + x_tick_number + x_tick_number \
                      + x_tick_number + x_tick_number + x_tick_number + x_tick_number + x_tick_number + x_tick_number \
                      + x_tick_number + x_tick_number + x_tick_number + x_tick_number + x_tick_number \
                      + x_tick_number + x_tick_number + x_tick_number
whole_y_coordinate_number = y_coordinate_GI1b + y_coordinate_GI5b + y_coordinate_GI2 + y_coordinate_GI5a2 \
                            + y_coordinate_GI5a1 + y_coordinate_GI7c + y_coordinate_GI6a + y_coordinate_GI4b \
                            + y_coordinate_GI4a + y_coordinate_GI3b2 + y_coordinate_GI3c + y_coordinate_GI3a \
                            + y_coordinate_GI3d + y_coordinate_GI1a + y_coordinate_GI9 + y_coordinate_GINA \
                            + y_coordinate_GI3b1 + y_coordinate_GI6b + y_coordinate_GI7a + y_coordinate_GI7b
whole_bubble_sizes = bubble_size[0] + bubble_size[1] + bubble_size[2] + bubble_size[3] + bubble_size[4] \
                     + bubble_size[5] + bubble_size[6] + bubble_size[7] + bubble_size[8] + bubble_size[9] \
                     + bubble_size[10] + bubble_size[11] + bubble_size[12] + bubble_size[13] + bubble_size[14] \
                     + bubble_size[15] + bubble_size[16] + bubble_size[17] + bubble_size[18] + bubble_size[19]
plt.scatter(whole_x_tick_number,
            whole_y_coordinate_number,
            s=whole_bubble_sizes,
            c=whole_bubble_sizes,
            cmap="binary",
            edgecolor='dimgray',
            linewidths=0.1)
plt.colorbar()
plt.xticks([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
           [x_name for x_number, x_name in zip(x_tick_number, new_x_ticks_rc)],
           fontsize=7, fontweight='bold', rotation=90, fontname='Arial')

plt.yticks([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
           [name for y_number, name in zip(y_tick_number, new_x_ticks_rc)],
           fontsize=7, fontweight='bold', fontname='Arial')
plt.xlabel('Region C lineages of GI, 2017-2018', fontsize=10, fontweight='bold', fontname='Arial')
plt.ylabel('Co-isolated region C lineages \nin identical samples', fontsize=10, fontweight='bold', fontname='Arial')
plt.xlim(0, 21)
plt.ylim(0, 21)
plt.savefig('fig6e.png', dpi=200)

#Box plot1
plt.figure()
dict_for_box_plot = {}
dict_for_box_plot['LP'] = Lp_detection_number
dict_for_box_plot['HP'] = hp_detection_number
dict_for_box_plot['NHP'] = Nhp_detection_number
dict_for_box_plot['NP'] = non_p_detection_number
dict_for_box_plot[''] = []
boxprops = dict(linestyle='-', linewidth=2, color='black')
medianprops = dict(linestyle='--', linewidth=2, color='blue')
meanprops = dict(marker='D', markeredgecolor='black', markerfacecolor='black')
plt.boxplot([dict_for_box_plot[a] for a in ['HP', 'LP', 'NP', '', 'HP', 'NHP']],
            vert=True, notch=False, whis=1.5, meanprops=meanprops, boxprops=boxprops, showmeans=True,
            medianprops=medianprops, widths=(0.75))
plt.gca().set_xticklabels(['HP', 'LP', 'NP', '', 'HP', 'NHP'], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 5, 10, 15, 20, 25], fontsize=10, fontweight='bold', fontname='Arial')
plt.ylabel('Detection frequency', fontsize=15, fontweight='bold', fontname='Arial')
plt.savefig('fig6f.png', dpi=200)

#Box plot2
plt.figure()
dict_for_box_plot = {}
dict_for_box_plot['LP'] = Lp_total_co_isolated_seq
dict_for_box_plot['HP'] = hp_total_co_isolated_seq
dict_for_box_plot['NHP'] = Nhp_total_co_isolated_seq
dict_for_box_plot['NP'] = non_p_total_co_isolated_seq
dict_for_box_plot[''] = []
boxprops = dict(linestyle='-', linewidth=2, color='black')
medianprops = dict(linestyle='--', linewidth=2, color='blue')
meanprops = dict(marker='D', markeredgecolor='black', markerfacecolor='black')
plt.boxplot([dict_for_box_plot[a] for a in ['HP', 'LP', 'NP', '', 'HP', 'NHP']],
            vert=True, notch=False, whis=1.5, meanprops=meanprops, boxprops=boxprops, showmeans=True,
            medianprops=medianprops, widths=(0.75))
plt.gca().set_xticklabels(['HP', 'LP', 'NP', '', 'HP', 'NHP'], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 10, 20, 30, 40, 50], fontsize=12, fontweight='bold', fontname='Arial')
plt.ylabel('Total number of \nco-isolated cases', fontsize=12, fontweight='bold', fontname='Arial')
plt.savefig('fig6g.png', dpi=200)

#Box plot3
plt.figure()
dict_for_box_plot = {}
dict_for_box_plot['LP'] = Lp_diversity_of_co_isolated_lineage
dict_for_box_plot['HP'] = hp_diversity_of_co_isolated_lineage
dict_for_box_plot['NHP'] = Nhp_diversity_of_co_isolated_lineage
dict_for_box_plot['NP'] = non_p_diversity_of_co_isolated_lineage
dict_for_box_plot[''] = []
boxprops = dict(linestyle='-', linewidth=2, color='black')
medianprops = dict(linestyle='--', linewidth=2, color='blue')
meanprops = dict(marker='D', markeredgecolor='black', markerfacecolor='black')
plt.boxplot([dict_for_box_plot[a] for a in ['HP', 'LP', 'NP', '', 'HP', 'NHP']],
            vert=True, notch=False, whis=1.5, meanprops=meanprops, boxprops=boxprops, showmeans=True,
            medianprops=medianprops, widths=(0.75))
plt.gca().set_xticklabels(['HP', 'LP', 'NP', '', 'HP', 'NHP'], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 5, 10, 15], fontsize=12, fontweight='bold', fontname='Arial')
plt.ylabel('Total number of types of \nco-isolated region C lineages',
           fontsize=12, fontweight='bold', fontname='Arial')
plt.savefig('fig6h.png', dpi=200)

#data for Mann-Whitney test
with open('GI_box_plot_data_for_MW_U_test_2017-2018.csv', 'wb') as csv_out_file1:
    csv_filewriter1 = csv.writer(csv_out_file1)
    csv_filewriter1.writerow(['detection_frequency_of_P(HP+LP)'] + p_detection_number)
    csv_filewriter1.writerow(['detection_frequency_of_HP'] + hp_detection_number)
    csv_filewriter1.writerow(['detection_frequency_of_NHP'] + Nhp_detection_number)
    csv_filewriter1.writerow(['detection_frequency_of_NP'] + non_p_detection_number)
    csv_filewriter1.writerow(['detection_frequency_of_LP'] + Lp_detection_number)
    csv_filewriter1.writerow(['total_number_of_co-isolated_cases_of_P(HP+LP)'] + p_total_co_isolated_seq)
    csv_filewriter1.writerow(['total_number_of_co-isolated_cases_of_HP'] + hp_total_co_isolated_seq)
    csv_filewriter1.writerow(['total_number_of_co-isolated_cases_of_NHP'] + Nhp_total_co_isolated_seq)
    csv_filewriter1.writerow(['total_number_of_co-isolated_cases_of_NP'] + non_p_total_co_isolated_seq)
    csv_filewriter1.writerow(['total_number_of_co-isolated_cases_of_LP'] + Lp_total_co_isolated_seq)
    csv_filewriter1.writerow(['total_number_of_types_of_co-isolated_lineages_of_P(HP+LP)'] + p_diversity_of_co_isolated_lineage)
    csv_filewriter1.writerow(['total_number_of_types_of_co-isolated_lineages_of_HP'] + hp_diversity_of_co_isolated_lineage)
    csv_filewriter1.writerow(['total_number_of_types_of_co-isolated_lineages_of_NHP'] + Nhp_diversity_of_co_isolated_lineage)
    csv_filewriter1.writerow(['total_number_of_types_of_co-isolated_lineages_of_NP'] + non_p_diversity_of_co_isolated_lineage)
    csv_filewriter1.writerow(['total_number_of_types_of_co-isolated_lineages_of_LP'] + Lp_diversity_of_co_isolated_lineage)