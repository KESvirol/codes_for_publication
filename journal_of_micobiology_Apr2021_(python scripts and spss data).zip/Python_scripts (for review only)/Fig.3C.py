#!/usr/bin/env python
import csv
import matplotlib.pyplot as plt
import re
import random

month_site_dic = {}
row_list = []
temp_list = []
sampled_site_list_water = []
y_data_for_kind_of_provinces_water = []
x_data_for_detection_score_water = []
P_diff_list1 = []
P_diff_list2 = []
P_diff_list_E1_E2 = []

#sampling_months_and_those_sampling_sites
y1_water = ('2014-03', '2014-04', '2014-05', '2014-07', '2014-08', '2014-09', '2014-10', '2015-01', '2015-02')
y2_water = ('2015-03')
y3_water = ('2015-05')
y4_water = ('2015-07', '2015-09', '2015-12')
y5_water = ('2016-01')
y6_water = ('2016-02')
y7_water = ('2016-03')
y8_water = ('2016-05')
y9_water = ('2017-10', '2017-11', '2017-12', '2018-02', '2018-04')
y10_water = ('2018-06', '2018-08', '2018-10', '2018-12', '2019-02', '2019-04', '2019-06', '2019-08', '2019-10',
             '2019-12', '2020-02', '2020-04')
y_list = [y1_water, y2_water, y3_water, y4_water, y5_water, y6_water, y7_water, y8_water]
month_site_dic[y1_water] = ['DL01', 'EL01', 'EL02', 'EL03', 'EL04', 'EL05', 'EL06', 'FL01', 'FL02', 'FL03', 'FL04',
                            'FL05', 'FL06', 'GL01', 'GL02', 'GL03', 'GL04', 'GL05', 'GL06', 'DM01', 'DM02', 'EM01',
                            'EM02', 'EM03', 'EM04', 'EM05', 'EM06', 'EM07', 'EM08', 'EM09', 'EM10', 'EM11', 'EM12',
                            'EM13', 'EM14', 'FM01', 'FM02', 'FM03', 'FM04', 'FM05', 'FM06', 'FM07', 'FM08', 'FM09',
                            'FM10', 'FM11', 'FM12', 'FM13', 'FM14', 'GM01', 'GM02', 'GM03', 'GM04', 'GM05', 'GM06',
                            'GM07', 'GM08', 'GM09', 'GM10', 'GM11', 'GM12', 'GM13', 'GM14']
month_site_dic[y2_water] = ['DL01A', 'DL01B', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A', 'EL03B', 'EL06',
                            'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A',
                            'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A', 'GL02B', 'GL02C',
                            'GL06', 'GL06A', 'GL06B', 'GL06C']
month_site_dic[y3_water] = ['DL01A', 'DL01C', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A', 'EL03B', 'EL06',
                            'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A',
                            'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A', 'GL02B', 'GL02C',
                            'GL06', 'GL06A', 'GL06B', 'GL06C']
month_site_dic[y4_water] = ['DL01A', 'DL01C', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A',
                            'EL03B', 'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D',
                            'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A',
                            'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C']
month_site_dic[y5_water] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL03', 'EL03A',
                            'EL03B', 'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D',
                            'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A',
                            'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C']
month_site_dic[y6_water] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D', 'EL02E',
                            'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL03A', 'EL03B', 'EL06', 'EL06A', 'EL07', 'EL07A',
                            'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A',
                            'FL07B', 'FL08', 'FL08A', 'FL08B', 'FL08C', 'FL08D', 'GL01', 'GL01A', 'GL01B', 'GL02',
                            'GL02A', 'GL02A1', 'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C', 'GL06D', 'GL06E',
                            'GL08', 'GL08A', 'GL08B']
month_site_dic[y7_water] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D', 'EL02E',
                            'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL06', 'EL06A', 'EL07', 'EL07A', 'FL01', 'FL01A',
                            'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL04B', 'FL07', 'FL07A', 'FL07B', 'FL08',
                            'FL08A', 'FL08B', 'FL08C', 'FL08D', 'GL01', 'GL01A', 'GL01B', 'GL02', 'GL02A', 'GL02A1',
                            'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C', 'GL06D', 'GL06E', 'GL08', 'GL08A',
                            'GL08B']
month_site_dic[y8_water] = ['DL01A', 'DL01B', 'DL02', 'DL02A', 'EL02', 'EL02A', 'EL02B', 'EL02C', 'EL02D', 'EL02E',
                            'EL02F', 'EL02G', 'EL02H', 'EL03', 'EL06', 'EL06A', 'EL07', 'EL07A', 'EL08', 'EL09',
                            'EL09A', 'FL01', 'FL01A', 'FL01B', 'FL01C', 'FL01D', 'FL04', 'FL04A', 'FL07', 'FL07A',
                            'FL07B', 'FL08', 'FL08A', 'FL08B', 'FL08C', 'FL08D', 'GL01', 'GL02', 'GL02A', 'GL02A1',
                            'GL02B', 'GL02C', 'GL06', 'GL06A', 'GL06B', 'GL06C', 'GL06D', 'GL06E', 'GL08', 'GL08A',
                            'GL08B']
month_site_dic[y9_water] = ['AM', 'AS', 'DL02', 'FL01B', 'MW']
month_site_dic[y10_water] = ['AM', 'AS01', 'DL02', 'FL01B', 'MW']

#regionC_lineages
GII_genotype = ['GII.1', 'GII.2a', 'GII.2b', 'GII.2c', 'GII.3b', 'GII.3c', 'GII.4s', 'GII.4ns', 'GII.5', 'GII.6a',
                'GII.6b', 'GII.6c', 'GII.8', 'GII.9', 'GII.11a', 'GII.11b', 'GII.11c', 'GII.13', 'GII.14', 'GII.17o',
                'GII.17n', 'GII.18', 'GII.21']

#randomized_sampling
def rd(date, site_samples):
    temp_list = []
    if row1[4] in month_site_dic[date]:
        for element in month_site_dic[date]:
            if len(re.findall(row1[4][0], element[0])) > 0:
                temp_list.append(element)
        if len(temp_list) == 1:
            site_samples.append(temp_list[0])
        else:
            samples = random.sample(temp_list, 1)
            if row1[4] == samples[0]:
                site_samples.append(samples[0])
    return site_samples

#randomized_sampling_data_production
with open('Fig.3c(Random_sampling_data).csv', 'wb') as csv_out_file2:
    csv_filewriter2 = csv.writer(csv_out_file2)
    with open('seqs_GII_rc_14-20.csv', 'rb') as csv_in_file1:
        filereader = csv.reader(csv_in_file1)
        for row in filereader:
            row_list.append(row)
        for n, genotype in enumerate(GII_genotype):
            y_data_for_kind_of_provinces_water.append(genotype + '_y_provinces')
            x_data_for_detection_score_water.append(genotype + '_x_sites')
            repeat_index = 1000
            while repeat_index > 0:
                set_list = []
                if genotype == row_list[0][8 + n].replace('\t', ''):
                    for row1 in row_list:
                        complement_number = 23 - len(row1)
                        while complement_number > 0:
                            row1.append('-')
                            complement_number = complement_number - 1
                        if row1[8 + n] == 'positive':
                            aa = []
                            aa.append(row1[1:8])
                            if aa in set_list:
                                continue
                            else:
                                set_list.append(aa)
                                if row1[1][:7] in y1_water:
                                    rd(y1_water, sampled_site_list_water)
                                elif row1[1][:7] in y2_water:
                                    rd(y2_water, sampled_site_list_water)
                                elif row1[1][:7] in y3_water:
                                    rd(y3_water, sampled_site_list_water)
                                elif row1[1][:7] in y4_water:
                                    rd(y4_water, sampled_site_list_water)
                                elif row1[1][:7] in y5_water:
                                    rd(y5_water, sampled_site_list_water)
                                elif row1[1][:7] in y6_water:
                                    rd(y6_water, sampled_site_list_water)
                                elif row1[1][:7] in y7_water:
                                    rd(y7_water, sampled_site_list_water)
                                elif row1[1][:7] in y8_water:
                                    rd(y8_water, sampled_site_list_water)
                                elif row1[1][:7] in y9_water:
                                    if row1[4] in month_site_dic[y9_water]:
                                        for element in month_site_dic[y9_water]:
                                            if len(re.findall(row1[4][0], element[0])) > 0:
                                                temp_list.append(element)
                                        if len(temp_list) == 1:
                                            if len(re.findall('M', temp_list[0][0])) > 0:
                                                sampled_site_list_water.append('E')
                                            else:
                                                sampled_site_list_water.append(temp_list[0])
                                        else:
                                            samples = random.sample(temp_list, 1)
                                            if row1[4] == samples[0]:
                                                if len(re.findall('M', samples[0][0])) > 0:
                                                    sampled_site_list_water.append('E')
                                                else:
                                                    sampled_site_list_water.append(samples[0])
                                        temp_list = []
                                elif row1[1][:7] in y10_water:
                                    if row1[4] in month_site_dic[y10_water]:
                                        for element in month_site_dic[y10_water]:
                                            if len(re.findall(row1[4][0], element[0])) > 0:
                                                temp_list.append(element)
                                        if len(temp_list) == 1:
                                            if len(re.findall('M', temp_list[0][0])) > 0:
                                                sampled_site_list_water.append('E')
                                            else:
                                                sampled_site_list_water.append(temp_list[0])
                                        else:
                                            samples = random.sample(temp_list, 1)
                                            if row1[4] == samples[0]:
                                                if len(re.findall('M', samples[0][0])) > 0:
                                                    sampled_site_list_water.append('E')
                                                else:
                                                    sampled_site_list_water.append(samples[0])
                                        temp_list = []
                                else:
                                    print('error')
                                    break
                        else:
                            continue
                    repeat_index = repeat_index - 1
                y_data_for_kind_of_provinces_water.append(len(list(set([s[:1] for s in sampled_site_list_water]))))
                x_data_for_detection_score_water.append(len(sampled_site_list_water))
                sampled_site_list_water = []

            #preparation_of_randomized_sampling_data_in_a_csv_file
            csv_filewriter2.writerow(x_data_for_detection_score_water)
            csv_filewriter2.writerow(y_data_for_kind_of_provinces_water)
            y_data_for_kind_of_provinces_water = []
            x_data_for_detection_score_water = []

#parsing_of_randomized_sampling_data
row_list2 = []
x_coordinate_mean_value = []
y_coordinate_mean_value = []
with open('Fig.3C(Random_sampling_data).csv', 'rb') as csv_in_file:
    filereader2 = csv.reader(csv_in_file)
    for r in filereader2:
        row_list2.append(r)
    for lineage in GII_genotype:
        for row2 in row_list2:
            if lineage == row2[0].replace('_x_sites', ''):
                x_coordinate_mean_value.append(round((sum(float(a) for a in row2[1:])/(len(row2)-1)), 3))
            if lineage == row2[0].replace('_y_provinces', ''):
                y_coordinate_mean_value.append(round((sum(float(a) for a in row2[1:])/(len(row2)-1)), 3))
#scatter_plot
plt.figure()
x_y_zip = zip(x_coordinate_mean_value, y_coordinate_mean_value)
aver_x_ticks = sum(x_coordinate_mean_value)/len(x_coordinate_mean_value)
aver_y_ticks = sum(y_coordinate_mean_value)/len(y_coordinate_mean_value)
for pcc_element in x_y_zip:
    P_diff_list1.append(pcc_element[0] - aver_x_ticks)
    P_diff_list2.append(pcc_element[1] - aver_y_ticks)
    P_diff_list_E1_E2.append((pcc_element[0]
                              - aver_x_ticks)*(pcc_element[1] - aver_y_ticks))
P_correlation_coefficient = sum(P_diff_list_E1_E2) \
                            / (((sum(k**2 for k in P_diff_list1))**0.5) * ((sum(k**2 for k in P_diff_list2))**0.5))
plt.scatter(x_coordinate_mean_value, y_coordinate_mean_value, marker='o', color='blue', s=20)
plt.xlim(-1, max(x_coordinate_mean_value) + 1)
plt.ylim(-1, max(y_coordinate_mean_value) + 1)
plt.xticks([0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 1, 2, 3, 4, 5], fontsize=15, fontweight='bold', fontname='Arial')
plt.xlabel('Detection frequency (Number of positive sampling sites)', fontsize=15, fontweight='bold', fontname='Arial')
plt.ylabel('Number of positive provinces', fontsize=15, fontweight='bold', fontname='Arial')
plt.text(0, 5, 'PCC={}'.format(round(P_correlation_coefficient, 3)), fontweight='bold', fontname='Arial', fontsize=13)
plt.tight_layout(pad=0)
plt.savefig('Fig.3C.png', dpi=200)
plt.show()

#scatter_plot_with_lineage_name
plt.scatter(x_coordinate_mean_value, y_coordinate_mean_value, marker='o', edgecolor='black', color='blue', s=20)
for i, txt in enumerate(GII_genotype):
    plt.annotate(txt, (x_coordinate_mean_value[i], y_coordinate_mean_value[i]),
                 xytext=(x_coordinate_mean_value[i],
                         y_coordinate_mean_value[i]), color='red')
plt.xlim(-1, max(x_coordinate_mean_value) + 3)
plt.ylim(-1, max(y_coordinate_mean_value) + 1)
plt.xticks([0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24], fontsize=15, fontweight='bold', fontname='Arial')
plt.yticks([0, 1, 2, 3, 4, 5], fontsize=15, fontweight='bold', fontname='Arial')
plt.xlabel('Detection frequency (Number of positive sampling sites)', fontsize=15, fontweight='bold', fontname='Arial')
plt.ylabel('Number of positive provinces', fontsize=15, fontweight='bold', fontname='Arial')
plt.tight_layout(pad=0)
plt.savefig('Fig.3C_lineage_name.png', dpi=200)
plt.show()