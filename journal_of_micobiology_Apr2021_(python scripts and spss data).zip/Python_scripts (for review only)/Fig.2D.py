#!/usr/bin/env python
from Bio import AlignIO
import csv
import matplotlib.pyplot as plt
import re

pattern_sample = re.compile('(\d\d\d\d\d\d\d\d_\D+\w+_\d\d_GII)')
pattern_clone = re.compile('(_\d\d_GII)')
pattern_two_num = re.compile('GII.\d\d')

#RegionC_lineages
pattern_list_dic1 = {'GII.1': [re.compile('(GII.1)')],
                     'GII.2a': [re.compile('(GII.2a)')],
                     'GII.2b': [re.compile('(GII.2b)')],
                     'GII.2c': [re.compile('(GII.2c)')],
                     'GII.3b': [re.compile('(GII.3b)')],
                     'GII.3c': [re.compile('(GII.3c)')],
                     'GII.4ns': [re.compile('(GII.4ns)')],
                     'GII.4s': [re.compile('(GII.4s)')],
                     'GII.5': [re.compile('(GII.5)')],
                     'GII.6a': [re.compile('(GII.6a)')],
                     'GII.6b': [re.compile('(GII.6b)')],
                     'GII.6c': [re.compile('(GII.6c)')],
                     'GII.8': [re.compile('(GII.8)')]}
pattern_list_dic2 = {'GII.11a': [re.compile('(GII.11a)')],
                     'GII.11b': [re.compile('(GII.11b)')],
                     'GII.11c': [re.compile('(GII.11c)')],
                     'GII.12': [re.compile('(GII.12)')],
                     'GII.13': [re.compile('(GII.13)')],
                     'GII.14': [re.compile('(GII.14)')],
                     'GII.17n': [re.compile('(GII.17n)')],
                     'GII.17o': [re.compile('(GII.17o)')],
                     'GII.18': [re.compile('(GII.18)')],
                     'GII.21': [re.compile('(GII.21)')]}

#counting_of_positive_samples_for_each_lineage
whole_dic2 = {}
seq_name_step1 = []
seq_name_step2 = []
alignment1 = AlignIO.read('alignment_GII_regionC_2014-2020_st_sea.fas', "fasta")
for lineage in pattern_list_dic1.keys():
    for record1 in alignment1:
        if len(re.findall(pattern_two_num, str(record1.id))) == 0:
            if len(re.findall(pattern_list_dic1[lineage][0], str(record1.id))) > 0:
                seq_name_step1.append(record1.id)
            else:
                continue
    for seq_name in seq_name_step1:
        seq_name_step2.append(re.findall(pattern_sample, seq_name)[0]
                             .replace(re.findall(pattern_clone, seq_name)[0], ''))
    whole_dic2[lineage] = [len(list(set(seq_name_step2)))]
    seq_name_step1 = []
    seq_name_step2 = []
for lineage in pattern_list_dic2.keys():
    for record1 in alignment1:
        if len(re.findall(pattern_two_num, str(record1.id))) > 0:
            if len(re.findall(pattern_list_dic2[lineage][0], str(record1.id))) > 0:
                seq_name_step1.append(record1.id)
            else:
                continue
    for seq_name in seq_name_step1:
        seq_name_step2.append(re.findall(pattern_sample, seq_name)[0]
                             .replace(re.findall(pattern_clone, seq_name)[0], ''))
    whole_dic2[lineage] = [len(list(set(seq_name_step2)))]
    seq_name_step1 = []
    seq_name_step2 = []

#A bar plot
def number(t):
    return(t[1])
xlables = []
y_value = []
plt.figure(figsize=(8, 4), dpi=200)
for lineage in whole_dic2.keys():
    xlables.append(lineage)
    y_value.append(whole_dic2[lineage][0])
zip_x_xlables = zip(xlables, y_value)
zip_x_xlables.sort(key=number, reverse=True)
new_x_ticks_rc = [x for x, y in zip_x_xlables]
new_y_ticks_rc = [y for x, y in zip_x_xlables]
plt.xlim(-1, len(new_x_ticks_rc))
plt.bar(new_x_ticks_rc, new_y_ticks_rc, tick_label=new_x_ticks_rc, align='center', edgecolor='black')
plt.xticks(fontsize=13, fontweight='bold', fontname='Arial', rotation=90)
plt.yticks(fontsize=13, fontweight='bold', fontname='Arial', rotation=90)
plt.xlabel('Region C lineages of GII', fontsize=15, fontweight='bold', fontname='Arial', rotation=180)
plt.ylabel('Positive water samples(N)', fontsize=14, fontweight='bold', fontname='Arial')
plt.yticks([0, 25, 50, 75, 100, 125, 150])
plt.tight_layout(pad=0)
plt.savefig('Fig.2D.png', dpi=200)
plt.show()













