#!/usr/bin/env python
from Bio import AlignIO
import csv
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import random
import re

whole_dic_wp = {}
whole_dic_wp_seq1_name = {}
whole_dic_wp_seq2_name = {}
whole_dic_bp = {}
whole_dic_bp_seq1_name = {}
whole_dic_bp_seq2_name = {}
dist_list_for_nt_wp = []
dist_list_for_nt_bp = []
dist_list_for_nt_wp_seq1_name = []
dist_list_for_nt_wp_seq2_name = []
dist_list_for_nt_bp_seq1_name = []
dist_list_for_nt_bp_seq2_name = []
whole_seq_names = []
length_list = []
seq_name_for_GD = []
nt_seqs_for_GD = []
pattern_subgenotype = re.compile('GII.\S+')
pattern_two_num = re.compile('GII.\d\d')
pattern_clone = re.compile('(_\d\d_GII)')
pattern_site = re.compile('(_\D+\w+_)')
pattern_sample = re.compile('(\d\d\d\d\d\d\d\d_\D+\w+_\d\d_GII)')
study_region_head = ['AM', 'AS', 'DL', 'DM', 'EL', 'EM', 'FL', 'FM', 'GL', 'GM', 'MW']
province_initial_dic = {}

#connection_between_sites_and_corresponding_provinces
for element in study_region_head:
    if element == ('AM'):
        province_initial_dic[element] = 'Gg'
    elif element == ('AS'):
        province_initial_dic[element] = 'Gg'
    elif element == ('DL'):
        province_initial_dic[element] = 'NG'
    elif element == ('DM'):
        province_initial_dic[element] = 'NG'
    elif element == ('EL'):
        province_initial_dic[element] = 'SG'
    elif element == ('EM'):
        province_initial_dic[element] = 'SG'
    elif element == ('FL'):
        province_initial_dic[element] = 'SJ'
    elif element == ('FM'):
        province_initial_dic[element] = 'SJ'
    elif element == ('GL'):
        province_initial_dic[element] = 'NJ'
    elif element == ('GM'):
        province_initial_dic[element] = 'NJ'
    elif element == ('MW'):
        province_initial_dic[element] = 'SG'

#regionC_lineages
pattern_list_dic0 = {'GII.2': [re.compile('(GII.2)')],
                     'GII.3': [re.compile('(GII.3)')],
                     'GII.4': [re.compile('(GII.4)')],
                     'GII.6': [re.compile('(GII.6)')],
                     'GII.11': [re.compile('(GII.11)')],
                     'GII.17': [re.compile('(GII.17)')]}
pattern_list_dic1 = {'GII.2': [re.compile('(GII.2)')],
                     'GII.3': [re.compile('(GII.3)')],
                     'GII.4': [re.compile('(GII.4)')],
                     'GII.6': [re.compile('(GII.6)')]}
pattern_list_dic2 = {'GII.11': [re.compile('(GII.11)')],
                     'GII.17': [re.compile('(GII.17)')]}

def number_of_difference(seq1, seq2):
    p = 0
    pairs = []
    for nucleotide in zip(seq1, seq2):
        if '-' not in nucleotide:
            pairs.append(nucleotide)
    for (x, y) in pairs:
        if x != y:
            p += 1
    return float(p) / len(pairs)

#calcuclation_of_sequence_group_distances_of_within/between_province
def GD(wsn, srh, dict_fs, dist_list_for_nt_wp, dist_list_for_nt_bp, dist_list_for_nt_wp_seq1_name,
       dist_list_for_nt_wp_seq2_name, dist_list_for_nt_bp_seq1_name, dist_list_for_nt_bp_seq2_name):
    temp_provinces = []
    for i, S1 in enumerate(wsn):
        for j, S2 in enumerate(wsn):
            if j >= i:
                break
            else:
                samples = [S1, S2]
                for s in samples:
                    site = re.findall(pattern_site, s)
                    site[0] = re.sub(pattern_clone, '', site[0])
                    site[0] = re.sub('_', '', site[0])
                    for hd in srh:
                        if len(re.findall(hd, site[0])) > 0:
                            temp_provinces.append(province_initial_dic[hd])
                        else:
                            continue
                if len(list(set(temp_provinces))) == 1:
                    if re.findall(pattern_sample, S1)[0].replace(re.findall(pattern_clone, S1)[0], '') \
                            != re.findall(pattern_sample, S2)[0].replace(re.findall(pattern_clone, S2)[0], ''):
                        seq_a = dict_fs[S1]
                        seq_b = dict_fs[S2]
                        dist_list_for_nt_wp.append(number_of_difference(seq_a, seq_b))
                        dist_list_for_nt_wp_seq1_name.append(S1)
                        dist_list_for_nt_wp_seq2_name.append(S2)
                    elif re.findall(pattern_sample, S1)[0].replace(re.findall(pattern_clone, S1)[0], '') \
                            == re.findall(pattern_sample, S2)[0].replace(re.findall(pattern_clone, S2)[0], ''):
                        if re.findall(pattern_subgenotype, S1)[0] != re.findall(pattern_subgenotype, S2)[0]:
                            seq_a = dict_fs[S1]
                            seq_b = dict_fs[S2]
                            dist_list_for_nt_wp.append(number_of_difference(seq_a, seq_b))
                            dist_list_for_nt_wp_seq1_name.append(S1)
                            dist_list_for_nt_wp_seq2_name.append(S2)
                elif len(list(set(temp_provinces))) > 1:
                    if re.findall(pattern_sample, S1)[0].replace(re.findall(pattern_clone, S1)[0], '') \
                            != re.findall(pattern_sample, S2)[0].replace(re.findall(pattern_clone, S2)[0], ''):
                        seq_a = dict_fs[S1]
                        seq_b = dict_fs[S2]
                        dist_list_for_nt_bp.append(number_of_difference(seq_a, seq_b))
                        dist_list_for_nt_bp_seq1_name.append(S1)
                        dist_list_for_nt_bp_seq2_name.append(S2)
                else:
                    print('error')
                    break
                temp_provinces = []
    return (dist_list_for_nt_wp, dist_list_for_nt_wp_seq1_name, dist_list_for_nt_wp_seq2_name,
            dist_list_for_nt_bp, dist_list_for_nt_bp_seq1_name, dist_list_for_nt_bp_seq2_name)

#distance_data_production
alignment1 = AlignIO.read('alignment_GII_regionC_2014-2020_st_sea.fas', "fasta")
with open('Fig.3B_(group_distance).csv', 'wb') as csv_out_file1:
    csv_filewriter = csv.writer(csv_out_file1)
    for lineage in pattern_list_dic1.keys():
        for record1 in alignment1:
            if len(re.findall(pattern_two_num, str(record1.id))) == 0:
                if len(re.findall(pattern_list_dic1[lineage][0], str(record1.id))) > 0:
                    whole_seq_names.append(record1.id)
                    seq_name_for_GD.append(str(record1.id))
                    nt_seqs_for_GD.append(str(record1.seq))
                else:
                    continue
            if len(dist_list_for_nt_wp) == 0:
                dist_list_for_nt_wp.append(lineage + '_within_province_distances')
                dist_list_for_nt_wp_seq1_name.append(lineage + '_' + 'sequence1')
                dist_list_for_nt_wp_seq2_name.append(lineage + '_' + 'sequence2')
            if len(dist_list_for_nt_bp) == 0:
                dist_list_for_nt_bp.append(lineage + '_between_province_distances')
                dist_list_for_nt_bp_seq1_name.append(lineage + '_' + 'sequence1')
                dist_list_for_nt_bp_seq2_name.append(lineage + '_' + 'sequence2')
        dict_for_seq = dict(zip(seq_name_for_GD, nt_seqs_for_GD))
        GD(whole_seq_names, study_region_head, dict_for_seq, dist_list_for_nt_wp, dist_list_for_nt_bp,
           dist_list_for_nt_wp_seq1_name, dist_list_for_nt_wp_seq2_name, dist_list_for_nt_bp_seq1_name,
           dist_list_for_nt_bp_seq2_name)
        whole_dic_wp[lineage] = dist_list_for_nt_wp
        whole_dic_wp_seq1_name[lineage] = dist_list_for_nt_wp_seq1_name
        whole_dic_wp_seq2_name[lineage] = dist_list_for_nt_wp_seq2_name
        whole_dic_bp[lineage] = dist_list_for_nt_bp
        whole_dic_bp_seq1_name[lineage] = dist_list_for_nt_bp_seq1_name
        whole_dic_bp_seq2_name[lineage] = dist_list_for_nt_bp_seq2_name
        dist_list_for_nt_wp = []
        dist_list_for_nt_wp_seq1_name = []
        dist_list_for_nt_wp_seq2_name = []
        dist_list_for_nt_bp = []
        dist_list_for_nt_bp_seq1_name = []
        dist_list_for_nt_bp_seq2_name = []
        whole_seq_names = []
        seq_name_for_GD = []
        nt_seqs_for_GD = []
    for lineage in pattern_list_dic2.keys():
        for record1 in alignment1:
            if len(re.findall(pattern_two_num, str(record1.id))) > 0:
                if len(re.findall(pattern_list_dic2[lineage][0], str(record1.id))) > 0:
                    whole_seq_names.append(record1.id)
                    seq_name_for_GD.append(str(record1.id))
                    nt_seqs_for_GD.append(str(record1.seq))
                else:
                    continue
            if len(dist_list_for_nt_wp) == 0:
                dist_list_for_nt_wp.append(lineage + '_within_province_distances')
                dist_list_for_nt_wp_seq1_name.append(lineage + '_' + 'sequence1')
                dist_list_for_nt_wp_seq2_name.append(lineage + '_' + 'sequence2')
            if len(dist_list_for_nt_bp) == 0:
                dist_list_for_nt_bp.append(lineage + '_between_province_distances')
                dist_list_for_nt_bp_seq1_name.append(lineage + '_' + 'sequence1')
                dist_list_for_nt_bp_seq2_name.append(lineage + '_' + 'sequence2')
        dict_for_seq = dict(zip(seq_name_for_GD, nt_seqs_for_GD))
        GD(whole_seq_names, study_region_head, dict_for_seq, dist_list_for_nt_wp, dist_list_for_nt_bp,
           dist_list_for_nt_wp_seq1_name, dist_list_for_nt_wp_seq2_name, dist_list_for_nt_bp_seq1_name,
           dist_list_for_nt_bp_seq2_name)
        whole_dic_wp[lineage] = dist_list_for_nt_wp
        whole_dic_wp_seq1_name[lineage] = dist_list_for_nt_wp_seq1_name
        whole_dic_wp_seq2_name[lineage] = dist_list_for_nt_wp_seq2_name
        whole_dic_bp[lineage] = dist_list_for_nt_bp
        whole_dic_bp_seq1_name[lineage] = dist_list_for_nt_bp_seq1_name
        whole_dic_bp_seq2_name[lineage] = dist_list_for_nt_bp_seq2_name
        dist_list_for_nt_wp = []
        dist_list_for_nt_wp_seq1_name = []
        dist_list_for_nt_wp_seq2_name = []
        dist_list_for_nt_bp = []
        dist_list_for_nt_bp_seq1_name = []
        dist_list_for_nt_bp_seq2_name = []
        whole_seq_names = []
        seq_name_for_GD = []
        nt_seqs_for_GD = []

    #preparation_of_within/between_group_distance_data_in_a_csv_file
    length_list = [len(whole_dic_wp['GII.11']), len(whole_dic_bp['GII.11']),
                   len(whole_dic_wp['GII.2']), len(whole_dic_bp['GII.2']),
                   len(whole_dic_wp['GII.3']), len(whole_dic_bp['GII.3']),
                   len(whole_dic_wp['GII.4']), len(whole_dic_bp['GII.4']),
                   len(whole_dic_wp['GII.6']), len(whole_dic_bp['GII.6']),
                   len(whole_dic_wp['GII.17']), len(whole_dic_bp['GII.17'])]
    for lineage in pattern_list_dic0:
        while max(length_list) - len(whole_dic_wp[lineage]) > 0:
            whole_dic_wp[lineage].append('-')
            whole_dic_wp_seq1_name[lineage].append('-')
            whole_dic_wp_seq2_name[lineage].append('-')
        while max(length_list) - len(whole_dic_bp[lineage]) > 0:
            whole_dic_bp[lineage].append('-')
            whole_dic_bp_seq1_name[lineage].append('-')
            whole_dic_bp_seq2_name[lineage].append('-')
    zipdic1 = zip(whole_dic_wp_seq1_name['GII.11'], whole_dic_wp_seq2_name['GII.11'], whole_dic_wp['GII.11'],
            whole_dic_bp_seq1_name['GII.11'], whole_dic_bp_seq2_name['GII.11'], whole_dic_bp['GII.11'],
            whole_dic_wp_seq1_name['GII.2'], whole_dic_wp_seq2_name['GII.2'], whole_dic_wp['GII.2'],
            whole_dic_bp_seq1_name['GII.2'], whole_dic_bp_seq2_name['GII.2'], whole_dic_bp['GII.2'],
            whole_dic_wp_seq1_name['GII.3'], whole_dic_wp_seq2_name['GII.3'], whole_dic_wp['GII.3'],
            whole_dic_bp_seq1_name['GII.3'], whole_dic_bp_seq2_name['GII.3'], whole_dic_bp['GII.3'],
            whole_dic_wp_seq1_name['GII.4'], whole_dic_wp_seq2_name['GII.4'], whole_dic_wp['GII.4'],
            whole_dic_bp_seq1_name['GII.4'], whole_dic_bp_seq2_name['GII.4'], whole_dic_bp['GII.4'],
            whole_dic_wp_seq1_name['GII.6'], whole_dic_wp_seq2_name['GII.6'], whole_dic_wp['GII.6'],
            whole_dic_bp_seq1_name['GII.6'], whole_dic_bp_seq2_name['GII.6'], whole_dic_bp['GII.6'],
            whole_dic_wp_seq1_name['GII.17'], whole_dic_wp_seq2_name['GII.17'], whole_dic_wp['GII.17'],
            whole_dic_bp_seq1_name['GII.17'], whole_dic_bp_seq2_name['GII.17'], whole_dic_bp['GII.17'])
    for row in zipdic1:
        csv_filewriter.writerow(row)

#group_distance_plot_for_within/between_province_distance_groups
zipdic2 = [whole_dic_wp['GII.11'], whole_dic_bp['GII.11'], whole_dic_wp['GII.2'], whole_dic_bp['GII.2'],
      whole_dic_wp['GII.3'], whole_dic_bp['GII.3'], whole_dic_wp['GII.4'], whole_dic_bp['GII.4'],
      whole_dic_wp['GII.6'], whole_dic_bp['GII.6'], whole_dic_wp['GII.17'], whole_dic_bp['GII.17']]
fig = plt.figure(figsize=(8, 4), dpi=200)
ax = fig.add_subplot(111)
median_lists = []
med = []
between_tick_lists = []
between_dist_lists = []
for i, d in enumerate(zipdic2):
    between_tick_lists.append([(i*2 + 0.5 + random.random()) for a in d[1:] if a != '-'])
    between_dist_lists.append([a for a in d[1:] if a != '-'])
for id in between_dist_lists:
    for a in id:
        median_lists.append(abs(np.median(id) - a))
    med.append(median_lists)
for j, id in enumerate(between_dist_lists):
    plt.scatter(between_tick_lists[j], id, color='black', s=1, alpha=1)
    plt.scatter(j*2 + 1, np.mean(id), color='red', s=65, alpha=1, marker='D', edgecolors='black')
    plt.scatter(j*2 + 1, np.median(id), color='white', s=50, alpha=1, marker='o', edgecolors='black')
plt.gca().set_xticklabels(['GII.11_W', 'GII.11_B',  'GII.2_W', 'GII.2_B', 'GII.3_W', 'GII.3_B',
                           'GII.4_W', 'GII.4_B', 'GII.6_W', 'GII.6_B', 'GII.17_W', 'GII.17_B'],
                          fontsize=10, fontweight='bold', fontname='Arial')
plt.xticks([1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23 ], fontsize=10, fontweight='bold', fontname='Arial', rotation=45)
plt.ylabel('p-distances', fontsize=12, fontweight='bold', fontname='Arial')
y_fm = ticker.FormatStrFormatter('%.3f')
ax.yaxis.set_major_formatter(y_fm)
ax.yaxis.set_major_locator(ticker.MultipleLocator(0.025))
plt.xlim(-0, 25)
plt.tight_layout(pad=0)
plt.savefig('Fig.3B.png', dpi=200)
plt.show()