#!/usr/bin/env python
import csv
import matplotlib.pyplot as plt
import re

pattern_subgenotype = re.compile('GII.\S+')
pattern_site = re.compile('(_\D+\w+_)')
lineage_dic1 = {}
lineage_dic2 = {}
hm_positive_1p_mr_than_0site = []
hm_positive_only_1p_0 = []
hm_positive_1p_mr_than_1site = []
hm_positive_only_1p_1 = []
hm_positive_1p_mr_than_2site = []
hm_positive_only_1p_2 = []
pc_positive_1p_mr_than_0site = []
pc_positive_only_1p_0 = []
pc_positive_1p_mr_than_1site = []
pc_positive_only_1p_1 = []
pc_positive_1p_mr_than_2site = []
pc_positive_only_1p_2 = []
positive_list = []

#RegionC_lineages
GII_human_lineages = ['GII.5', 'GII.9', 'GII.2b', 'GII.14', 'GII.2c', 'GII.8',
                      'GII.3c', 'GII.6c']
GII_porcine_lineages = ['GII.11a', 'GII.11b', 'GII.11c', 'GII.18']

#Counting_of_positive_sampling_sites/provinces
def ct(lg, pl, site_number, list_s, list_p):
    for a in pl:
        for b in a.keys():
            temp_site_list = []
            for c in a[b]:
                temp_site_list.append(re.findall(pattern_site, c)[0])
            for site in list(set(temp_site_list)):
                if temp_site_list.count(site) > site_number:
                    list_s.append(lg)
                    if len(pl) == 1:
                        list_p.append(lg)
    return list_s, list_p

#Parsing_of_sampling_site/province_information1
for lineage in GII_human_lineages:
    lineage_dic1[lineage] = [{'North Gyeongsang': [], 'South Gyeongsang': [], 'North Jeolla': [],
                             'South Jeolla': [], 'Gyeonggi': []}]
with open('seqs_GII_rc_14-20.csv', 'rb') as csv_in_file1:
    row_list = []
    filereader = csv.reader(csv_in_file1)
    first_row = next(filereader)
    for row in filereader:
        row_list.append(str(row[1] + '_' + row[2] + '_' + row[4] + '_' + row[6] + row[7]))
    row_list2 = list(set(row_list))
    for lg in lineage_dic1.keys():
        for seq in row_list2:
            if re.findall(pattern_subgenotype, seq)[0] == lg:
                for xx in lineage_dic1[lg][0].keys():
                    if len(re.findall(xx, seq)) > 0:
                        lineage_dic1[lg][0][xx].append(seq)
for x in lineage_dic1.keys():
    for y in lineage_dic1[x][0].keys():
        if len(lineage_dic1[x][0][y]) == 0:
            continue
        else:
            positive_list.append({y: lineage_dic1[x][0][y]})
    ct(x, positive_list, 0, hm_positive_1p_mr_than_0site, hm_positive_only_1p_0)
    ct(x, positive_list, 1, hm_positive_1p_mr_than_1site, hm_positive_only_1p_1)
    ct(x, positive_list, 2, hm_positive_1p_mr_than_2site, hm_positive_only_1p_2)
    positive_list = []

#Parsing_of_sampling_site/province_information2
for lineage in GII_porcine_lineages:
    lineage_dic2[lineage] = [{'North Gyeongsang': [], 'South Gyeongsang': [], 'North Jeolla': [],
                             'South Jeolla': [], 'Gyeonggi': []}]
with open('seqs_GII_rc_14-20.csv', 'rb') as csv_in_file1:
    row_list = []
    filereader = csv.reader(csv_in_file1)
    first_row = next(filereader)
    for row in filereader:
        row_list.append(str(row[1] + '_' + row[2] + '_' + row[4] + '_' + row[6] + row[7]))
    row_list2 = list(set(row_list))
    for lg in lineage_dic2.keys():
        for seq in row_list2:
            if re.findall(pattern_subgenotype, seq)[0] == lg:
                for xx in lineage_dic2[lg][0].keys():
                    if len(re.findall(xx, seq)) > 0:
                        lineage_dic2[lg][0][xx].append(seq)
for x in lineage_dic2.keys():
    for y in lineage_dic2[x][0].keys():
        if len(lineage_dic2[x][0][y]) == 0:
            continue
        else:
            positive_list.append({y: lineage_dic2[x][0][y]})
    ct(x, positive_list, 0, pc_positive_1p_mr_than_0site, pc_positive_only_1p_0)
    ct(x, positive_list, 1, pc_positive_1p_mr_than_1site, pc_positive_only_1p_1)
    ct(x, positive_list, 2, pc_positive_1p_mr_than_2site, pc_positive_only_1p_2)
    positive_list = []

#Preparation_of_data_in_a_csv_file
with open('SFig.1D.csv', 'wb') as csv_out_file1:
    csv_filewriter = csv.writer(csv_out_file1)
    row1 = ['Human_GII_lineages\t', GII_human_lineages]
    row2 = ['Requirement1(R1)\t', 'Lineages_satisfying_the_minimum number_(>=N;_cut_off_value)_of_positive_samples'
                                  '_in_at_least_one_sampling_site']
    row3 = ['Requirement2(R2)\t', 'Lineages_satisfying_R1_and_emerging_in_only_one_province']
    row4 = ['Table', '1(R1)\t', '2(R1)\t', '3(R1)\t']
    row5 = ['Harvested_lineages(R1)']
    row6 = ['Harvested_lineages(R2)']
    row7 = ['The_number_of_harvested_lineages(R1)']
    row8 = ['The_number_of_harvested_lineages(R2)']
    row9 = ['Proportion_of_R2(R2/R1)']
    row10 = ''
    row11 = ['Porcine_GII_lineages\t', GII_porcine_lineages]
    row12 = ['Requirement1(R1)\t', 'Lineages_satisfying_the_minimum number_(>=N;_cut_off_value)_of_positive_samples'
                                   '_in_at_least_one_sampling_site']
    row13 = ['Requirement2(R2)\t', 'Lineages_satisfying_R1_and_emerging_in_only_one_province']
    row14 = ['Table', '1(R1)\t', '2(R1)\t', '3(R1)\t']
    row15 = ['Harvested_lineages(R1)']
    row16 = ['Harvested_lineages(R2)']
    row17 = ['The_number_of_harvested_lineages(R1)']
    row18 = ['The_number_of_harvested_lineages(R2)']
    row19 = ['Proportion_of_R2(R2/R1)']
    list1 = [list(set(hm_positive_1p_mr_than_0site)),
             list(set(hm_positive_1p_mr_than_1site)),
             list(set(hm_positive_1p_mr_than_2site))]
    list2 = [list(set(hm_positive_only_1p_0)),
             list(set(hm_positive_only_1p_1)),
             list(set(hm_positive_only_1p_2))]
    list3 = zip(list1, list2)
    for l1 in list1:
        row5.append(l1)
        row7.append(len(l1))
    for l2 in list2:
        row6.append(l2)
        row8.append(len(l2))
    for l3 in list3:
        row9.append(float(len(l3[1]))/float(len(l3[0])))
    list5 = [list(set(pc_positive_1p_mr_than_0site)),
             list(set(pc_positive_1p_mr_than_1site)),
             list(set(pc_positive_1p_mr_than_2site))]
    list6 = [list(set(pc_positive_only_1p_0)),
             list(set(pc_positive_only_1p_1)),
             list(set(pc_positive_only_1p_2))]
    list7 = zip(list5, list6)
    list8 = []
    for l1 in list5:
        row15.append(l1)
        row17.append(len(l1))
    for l2 in list6:
        row16.append(l2)
        row18.append(len(l2))
    for l3 in list7:
        row19.append(float(len(l3[1])) / float(len(l3[0])))
    wl = [row1, row2, row3, row4, row5, row6, row7, row8, row9, row10, row11, row12, row13, row14, row15, row16, row17,
          row18, row19]
    for rows in wl:
        csv_filewriter.writerow(rows)

#A_scatter_plot
fig = plt.figure(figsize=(4, 4), dpi=200)
x_axis_hm = [1, 2, 3]
x_axis_pc = [1, 2, 3]
y_axis_hm = []
y_axis_pc = []
y_axis_hm.append((float(len(list(set(hm_positive_only_1p_0))))
               /float(len(list(set(hm_positive_1p_mr_than_0site)))))*100)
y_axis_hm.append((float(len(list(set(hm_positive_only_1p_1))))
               /float(len(list(set(hm_positive_1p_mr_than_1site)))))*100)
y_axis_hm.append((float(len(list(set(hm_positive_only_1p_2))))
               /float(len(list(set(hm_positive_1p_mr_than_2site)))))*100)
y_axis_pc.append((float(len(list(set(pc_positive_only_1p_0))))
               /float(len(list(set(pc_positive_1p_mr_than_0site)))))*100)
y_axis_pc.append((float(len(list(set(pc_positive_only_1p_1))))
               /float(len(list(set(pc_positive_1p_mr_than_1site)))))*100)
y_axis_pc.append((float(len(list(set(pc_positive_only_1p_2))))
               /float(len(list(set(pc_positive_1p_mr_than_2site)))))*100)
plt.scatter(x_axis_hm, y_axis_hm, color='black', s=20, alpha=1)
plt.scatter(x_axis_pc, y_axis_pc, edgecolor='red', color='white', s=20, alpha=1)
plt.scatter(x_axis_pc[0], y_axis_pc[0], edgecolor='blue', color='white', s=20, alpha=1)
plt.xticks([1, 2, 3], fontsize=12, fontweight='bold', fontname='Arial')
plt.yticks([0, 20, 40, 60, 80, 100], fontsize=12, fontweight='bold', fontname='Arial')
plt.gca().set_xticklabels(['>=1', '>=2', '>=3'], fontsize=15, fontweight='bold', fontname='Arial', rotation=45)
plt.ylabel('Proportion of lineages emerged \nat only one province (%)', fontsize=12, fontweight='bold', fontname='Arial')
plt.xlabel('Number of positives \nin a sampling site',
           fontsize=12, fontweight='bold', fontname='Arial')
plt.tight_layout(pad=0)
plt.savefig('SFig.1D.png', dpi=200)
plt.show()