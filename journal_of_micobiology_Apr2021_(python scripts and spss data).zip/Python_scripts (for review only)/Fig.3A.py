#!/usr/bin/env python
from Bio import AlignIO
import csv
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import random
import re

whole_dic_between = {}
whole_dic_between_seq1_name = {}
whole_dic_between_seq2_name = {}
whole_dic_within = {}
whole_dic_within_seq1_name = {}
whole_dic_within_seq2_name = {}
seq_name_group1 = []
seq_name_group2 = []
seq_name_group3 = []
dist_list_for_nt_between = []
dist_list_for_nt_between_seq1_name_GD = []
dist_list_for_nt_between_seq2_name_GD = []
dist_list_for_nt_within = []
dist_list_for_nt_within_seq1_name_GD = []
dist_list_for_nt_within_seq2_name_GD = []
length_list = []
seq_name_for_whole = []
nt_seqs_for_whole = []
seq_name_group1_for_GD = []
nt_seqs_group1_for_GD = []
seq_name_group2_for_GD = []
nt_seqs_group2_for_GD = []
seq_name_group3_for_GD = []
nt_seqs_group3_for_GD = []
pattern_sample = re.compile('(\d\d\d\d\d\d\d\d_\D+\w+_\d\d_GII)')
pattern_clone = re.compile('(_\d\d_GII)')
pattern_subgenotype = re.compile('GII.\S+')
pattern_two_num = re.compile('GII.\d\d')

#regionC_lineages
pattern_list_dic0 = {'GII.2': [re.compile('(GII.2a)'), re.compile('(GII.2b)'), re.compile('(GII.2c)')],
                     'GII.3': [re.compile('(GII.3b)'), re.compile('(GII.3c)')],
                     'GII.4': [re.compile('(GII.4ns)'), re.compile('(GII.4s)')],
                     'GII.6': [re.compile('(GII.6a)'), re.compile('(GII.6b)'), re.compile('(GII.6c)')],
                     'GII.11': [re.compile('(GII.11a)'), re.compile('(GII.11b)'), re.compile('(GII.11c)')],
                     'GII.17': [re.compile('(GII.17n)'), re.compile('(GII.17o)')]}
pattern_list_dic1 = {'GII.2': [re.compile('(GII.2a)'), re.compile('(GII.2b)'), re.compile('(GII.2c)')],
                     'GII.3': [re.compile('(GII.3b)'), re.compile('(GII.3c)')],
                     'GII.4': [re.compile('(GII.4ns)'), re.compile('(GII.4s)')],
                     'GII.6': [re.compile('(GII.6a)'), re.compile('(GII.6b)'), re.compile('(GII.6c)')]}
pattern_list_dic2 = {'GII.11': [re.compile('(GII.11a)'), re.compile('(GII.11b)'), re.compile('(GII.11c)')],
                     'GII.17': [re.compile('(GII.17n)'), re.compile('(GII.17o)')]}
three_sub = ['GII.11', 'GII.2', 'GII.6']
def number_of_difference(seq1, seq2):
    p = 0
    pairs = []
    for nucleotide in zip(seq1, seq2):
        if '-' not in nucleotide:
            pairs.append(nucleotide)
    for (x, y) in pairs:
        if x != y:
            p += 1
    return float(p) / len(pairs)

#calcuclation_of_within_sug-genotype_distance
def within(wsn, dict_for_seq, dist, seq1_name, seq2_name):
    for i, s1 in enumerate(wsn):
        for j, s2 in enumerate(wsn):
            if j >= i:
                break
            else:
                if re.findall(pattern_sample, s1)[0].replace(re.findall(pattern_clone, s1)[0], '') \
                        != re.findall(pattern_sample, s2)[0].replace(re.findall(pattern_clone, s2)[0], ''):
                    seq_a = dict_for_seq[s1]
                    seq_b = dict_for_seq[s2]
                    dist.append(number_of_difference(seq_a, seq_b))
                    seq1_name.append(s1)
                    seq2_name.append(s2)
                elif re.findall(pattern_sample, s1)[0].replace(re.findall(pattern_clone, s1)[0], '') \
                        == re.findall(pattern_sample, s2)[0].replace(re.findall(pattern_clone, s2)[0], ''):
                    if re.findall(pattern_subgenotype, s1)[0] != re.findall(pattern_subgenotype, s2)[0]:
                        seq_a = dict_for_seq[s1]
                        seq_b = dict_for_seq[s2]
                        dist.append(number_of_difference(seq_a, seq_b))
                        seq1_name.append(s1)
                        seq2_name.append(s2)
                else:
                    print('error')
                    break
    return dist

#calcuclation_of_between_sub-genotype_distance
def between(wsn_1, wsn_2, dict_for_seq_1, dict_for_seq_2, dist, seq1_name, seq2_name):
    for s1 in wsn_1:
        for s2 in wsn_2:
            if re.findall(pattern_sample, s1)[0].replace(re.findall(pattern_clone, s1)[0], '') \
                    != re.findall(pattern_sample, s2)[0].replace(re.findall(pattern_clone, s2)[0], ''):
                seq_a = dict_for_seq_1[s1]
                seq_b = dict_for_seq_2[s2]
                dist.append(number_of_difference(seq_a, seq_b))
                seq1_name.append(s1)
                seq2_name.append(s2)
    return dist

#distance_data_production
alignment1 = AlignIO.read('alignment_GII_regionC_2014-2020_st_sea.fas', "fasta")
with open('Fig.3A_(group_distance).csv', 'wb') as csv_out_file1:
    csv_filewriter = csv.writer(csv_out_file1)
    for lineage in pattern_list_dic1.keys():
        if lineage not in three_sub:
            for record1 in alignment1:
                if len(re.findall(pattern_two_num, str(record1.id))) == 0:
                    if len(re.findall(pattern_list_dic1[lineage][0], str(record1.id))) > 0:
                        seq_name_group1.append(record1.id)
                        seq_name_group1_for_GD.append(str(record1.id))
                        nt_seqs_group1_for_GD.append(str(record1.seq))
                    elif len(re.findall(pattern_list_dic1[lineage][1], str(record1.id))) > 0:
                        seq_name_group2.append(record1.id)
                        seq_name_group2_for_GD.append(str(record1.id))
                        nt_seqs_group2_for_GD.append(str(record1.seq))
                    else:
                        continue
                    if len(dist_list_for_nt_between) == 0:
                        dist_list_for_nt_between.append(lineage + '_between_sub-genotype_distances')
                        dist_list_for_nt_between_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                        dist_list_for_nt_between_seq2_name_GD.append(lineage + '_' + 'sequence_2')
                    if len(dist_list_for_nt_within) == 0:
                        dist_list_for_nt_within.append(lineage + '_within_sub-genotype_distances')
                        dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                        dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'sequence_2')
            dict_for_seq_a = dict(zip(seq_name_group1_for_GD, nt_seqs_group1_for_GD))
            dict_for_seq_b = dict(zip(seq_name_group2_for_GD, nt_seqs_group2_for_GD))
            between(seq_name_group1, seq_name_group2, dict_for_seq_a, dict_for_seq_b, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            within(seq_name_group1, dict_for_seq_a, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group2, dict_for_seq_b, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
        else:
            for record1 in alignment1:
                if len(re.findall(pattern_list_dic1[lineage][0], str(record1.id))) > 0:
                    seq_name_group1.append(record1.id)
                    seq_name_group1_for_GD.append(str(record1.id))
                    nt_seqs_group1_for_GD.append(str(record1.seq))
                elif len(re.findall(pattern_list_dic1[lineage][1], str(record1.id))) > 0:
                    seq_name_group2.append(record1.id)
                    seq_name_group2_for_GD.append(str(record1.id))
                    nt_seqs_group2_for_GD.append(str(record1.seq))
                elif len(re.findall(pattern_list_dic1[lineage][2], str(record1.id))) > 0:
                    seq_name_group3.append(record1.id)
                    seq_name_group3_for_GD.append(str(record1.id))
                    nt_seqs_group3_for_GD.append(str(record1.seq))
                else:
                    continue
                if len(dist_list_for_nt_between) == 0:
                    dist_list_for_nt_between.append(lineage + '_between_sub-genotype_distances')
                    dist_list_for_nt_between_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_between_seq2_name_GD.append(lineage + '_' + 'sequence_2')
                if len(dist_list_for_nt_within) == 0:
                    dist_list_for_nt_within.append(lineage + '_within_sub-genotype_distances')
                    dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'sequence_2')
            dict_for_seq_a = dict(zip(seq_name_group1_for_GD, nt_seqs_group1_for_GD))
            dict_for_seq_b = dict(zip(seq_name_group2_for_GD, nt_seqs_group2_for_GD))
            dict_for_seq_c = dict(zip(seq_name_group3_for_GD, nt_seqs_group3_for_GD))
            between(seq_name_group1, seq_name_group2, dict_for_seq_a, dict_for_seq_b, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            between(seq_name_group1, seq_name_group3, dict_for_seq_a, dict_for_seq_c, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            between(seq_name_group2, seq_name_group3, dict_for_seq_b, dict_for_seq_c, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            within(seq_name_group1, dict_for_seq_a, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group2, dict_for_seq_b, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group3, dict_for_seq_c, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
        whole_dic_between[lineage] = dist_list_for_nt_between
        whole_dic_between_seq1_name[lineage] = dist_list_for_nt_between_seq1_name_GD
        whole_dic_between_seq2_name[lineage] = dist_list_for_nt_between_seq2_name_GD
        whole_dic_within[lineage] = dist_list_for_nt_within
        whole_dic_within_seq1_name[lineage] = dist_list_for_nt_within_seq1_name_GD
        whole_dic_within_seq2_name[lineage] = dist_list_for_nt_within_seq2_name_GD
        dist_list_for_nt_between = []
        dist_list_for_nt_between_seq1_name_GD = []
        dist_list_for_nt_between_seq2_name_GD = []
        dist_list_for_nt_within = []
        dist_list_for_nt_within_seq1_name_GD = []
        dist_list_for_nt_within_seq2_name_GD = []
        seq_name_group1 = []
        seq_name_group2 = []
        seq_name_group3 = []
        seq_name_group1_for_GD = []
        seq_name_group2_for_GD = []
        seq_name_group3_for_GD = []
        nt_seqs_group1_for_GD = []
        nt_seqs_group2_for_GD = []
        nt_seqs_group3_for_GD = []
    for lineage in pattern_list_dic2.keys():
        if lineage not in three_sub:
            for record1 in alignment1:
                if len(re.findall(pattern_list_dic2[lineage][0], str(record1.id))) > 0:
                    seq_name_group1.append(record1.id)
                    seq_name_group1_for_GD.append(str(record1.id))
                    nt_seqs_group1_for_GD.append(str(record1.seq))
                elif len(re.findall(pattern_list_dic2[lineage][1], str(record1.id))) > 0:
                    seq_name_group2.append(record1.id)
                    seq_name_group2_for_GD.append(str(record1.id))
                    nt_seqs_group2_for_GD.append(str(record1.seq))
                else:
                    continue
                if len(dist_list_for_nt_between) == 0:
                    dist_list_for_nt_between.append(lineage + '_between_sub-genotype_distances')
                    dist_list_for_nt_between_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_between_seq2_name_GD.append(lineage + '_' + 'sequence_2')
                if len(dist_list_for_nt_within) == 0:
                    dist_list_for_nt_within.append(lineage + '_within_sub-genotype_distances')
                    dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'sequence_2')
            dict_for_seq_a = dict(zip(seq_name_group1_for_GD, nt_seqs_group1_for_GD))
            dict_for_seq_b = dict(zip(seq_name_group2_for_GD, nt_seqs_group2_for_GD))
            between(seq_name_group1, seq_name_group2, dict_for_seq_a, dict_for_seq_b, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            within(seq_name_group1, dict_for_seq_a, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group2, dict_for_seq_b, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
        else:
            for record1 in alignment1:
                if len(re.findall(pattern_list_dic2[lineage][0], str(record1.id))) > 0:
                    seq_name_group1.append(record1.id)
                    seq_name_group1_for_GD.append(str(record1.id))
                    nt_seqs_group1_for_GD.append(str(record1.seq))
                elif len(re.findall(pattern_list_dic2[lineage][1], str(record1.id))) > 0:
                    seq_name_group2.append(record1.id)
                    seq_name_group2_for_GD.append(str(record1.id))
                    nt_seqs_group2_for_GD.append(str(record1.seq))
                elif len(re.findall(pattern_list_dic2[lineage][2], str(record1.id))) > 0:
                    seq_name_group3.append(record1.id)
                    seq_name_group3_for_GD.append(str(record1.id))
                    nt_seqs_group3_for_GD.append(str(record1.seq))
                else:
                    continue
                if len(dist_list_for_nt_between) == 0:
                    dist_list_for_nt_between.append(lineage + '_between_sub-genotype_distances')
                    dist_list_for_nt_between_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_between_seq2_name_GD.append(lineage + '_' + 'sequence_2')
                if len(dist_list_for_nt_within) == 0:
                    dist_list_for_nt_within.append(lineage + '_within_sub-genotype_distances')
                    dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                    dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'sequence_2')
            dict_for_seq_a = dict(zip(seq_name_group1_for_GD, nt_seqs_group1_for_GD))
            dict_for_seq_b = dict(zip(seq_name_group2_for_GD, nt_seqs_group2_for_GD))
            dict_for_seq_c = dict(zip(seq_name_group3_for_GD, nt_seqs_group3_for_GD))
            between(seq_name_group1, seq_name_group2, dict_for_seq_a, dict_for_seq_b, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            between(seq_name_group1, seq_name_group3, dict_for_seq_a, dict_for_seq_c, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            between(seq_name_group2, seq_name_group3, dict_for_seq_b, dict_for_seq_c, dist_list_for_nt_between,
                    dist_list_for_nt_between_seq1_name_GD, dist_list_for_nt_between_seq2_name_GD)
            within(seq_name_group1, dict_for_seq_a, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group2, dict_for_seq_b, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
            within(seq_name_group3, dict_for_seq_c, dist_list_for_nt_within, dist_list_for_nt_within_seq1_name_GD,
                   dist_list_for_nt_within_seq2_name_GD)
        whole_dic_between[lineage] = dist_list_for_nt_between
        whole_dic_between_seq1_name[lineage] = dist_list_for_nt_between_seq1_name_GD
        whole_dic_between_seq2_name[lineage] = dist_list_for_nt_between_seq2_name_GD
        whole_dic_within[lineage] = dist_list_for_nt_within
        whole_dic_within_seq1_name[lineage] = dist_list_for_nt_within_seq1_name_GD
        whole_dic_within_seq2_name[lineage] = dist_list_for_nt_within_seq2_name_GD
        dist_list_for_nt_between = []
        dist_list_for_nt_between_seq1_name_GD = []
        dist_list_for_nt_between_seq2_name_GD = []
        dist_list_for_nt_within = []
        dist_list_for_nt_within_seq1_name_GD = []
        dist_list_for_nt_within_seq2_name_GD = []
        seq_name_group1 = []
        seq_name_group2 = []
        seq_name_group3 = []
        seq_name_group1_for_GD = []
        seq_name_group2_for_GD = []
        seq_name_group3_for_GD = []
        nt_seqs_group1_for_GD = []
        nt_seqs_group2_for_GD = []
        nt_seqs_group3_for_GD = []

    #preparation_of_within-between_sub-genotype_distance_data_in_a_csv_file
    length_list = [len(whole_dic_within['GII.11']), len(whole_dic_between['GII.11']),
                   len(whole_dic_within['GII.2']), len(whole_dic_between['GII.2']),
                   len(whole_dic_within['GII.3']), len(whole_dic_between['GII.3']),
                   len(whole_dic_within['GII.4']), len(whole_dic_between['GII.4']),
                   len(whole_dic_within['GII.6']), len(whole_dic_between['GII.6']),
                   len(whole_dic_within['GII.17']), len(whole_dic_between['GII.17'])]
    for lineage in pattern_list_dic0:
        while max(length_list) - len(whole_dic_between[lineage]) > 0:
            whole_dic_between[lineage].append('-')
            whole_dic_between_seq1_name[lineage].append('-')
            whole_dic_between_seq2_name[lineage].append('-')
        while max(length_list) - len(whole_dic_within[lineage]) > 0:
            whole_dic_within[lineage].append('-')
            whole_dic_within_seq1_name[lineage].append('-')
            whole_dic_within_seq2_name[lineage].append('-')
    zd1 = zip(whole_dic_within_seq1_name['GII.11'], whole_dic_within_seq2_name['GII.11'], whole_dic_within['GII.11'],
            whole_dic_between_seq1_name['GII.11'], whole_dic_between_seq2_name['GII.11'], whole_dic_between['GII.11'],
            whole_dic_within_seq1_name['GII.2'], whole_dic_within_seq2_name['GII.2'], whole_dic_within['GII.2'],
            whole_dic_between_seq1_name['GII.2'], whole_dic_between_seq2_name['GII.2'], whole_dic_between['GII.2'],
            whole_dic_within_seq1_name['GII.3'], whole_dic_within_seq2_name['GII.3'], whole_dic_within['GII.3'],
            whole_dic_between_seq1_name['GII.3'], whole_dic_between_seq2_name['GII.3'], whole_dic_between['GII.3'],
            whole_dic_within_seq1_name['GII.4'], whole_dic_within_seq2_name['GII.4'], whole_dic_within['GII.4'],
            whole_dic_between_seq1_name['GII.4'], whole_dic_between_seq2_name['GII.4'], whole_dic_between['GII.4'],
            whole_dic_within_seq1_name['GII.6'], whole_dic_within_seq2_name['GII.6'], whole_dic_within['GII.6'],
            whole_dic_between_seq1_name['GII.6'], whole_dic_between_seq2_name['GII.6'], whole_dic_between['GII.6'],
            whole_dic_within_seq1_name['GII.17'], whole_dic_within_seq2_name['GII.17'], whole_dic_within['GII.17'],
            whole_dic_between_seq1_name['GII.17'], whole_dic_between_seq2_name['GII.17'], whole_dic_between['GII.17'])
    for row in zd1:
        csv_filewriter.writerow(row)

#within/between_sub-genotype_distance_plot
zd2 = [whole_dic_within['GII.11'], whole_dic_between['GII.11'], whole_dic_within['GII.2'], whole_dic_between['GII.2'],
      whole_dic_within['GII.3'], whole_dic_between['GII.3'], whole_dic_within['GII.4'], whole_dic_between['GII.4'],
      whole_dic_within['GII.6'], whole_dic_between['GII.6'], whole_dic_within['GII.17'], whole_dic_between['GII.17']]
fig = plt.figure(figsize=(8, 4), dpi=200)
ax = fig.add_subplot(111)
median_lists = []
med = []
between_tick_lists = []
between_dist_lists = []
for i, d in enumerate(zd2):
    between_tick_lists.append([(i*2 + 0.5 + random.random()) for a in d[1:] if a != '-'])
    between_dist_lists.append([a for a in d[1:] if a != '-'])
for id in between_dist_lists:
    for a in id:
        median_lists.append(abs(np.median(id) - a))
    med.append(median_lists)
for j, id in enumerate(between_dist_lists):
    plt.scatter(between_tick_lists[j], id, color='black', s=1, alpha=1)
    plt.scatter(j*2 + 1, np.mean(id), color='red', s=65, alpha=1, marker='D', edgecolors='black')
    plt.scatter(j*2 + 1, np.median(id), color='white', s=50, alpha=1, marker='o', edgecolors='black')
plt.gca().set_xticklabels(['GII.11_W', 'GII.11_B',  'GII.2_W', 'GII.2_B', 'GII.3_W', 'GII.3_B',
                           'GII.4_W', 'GII.4_B', 'GII.6_W', 'GII.6_B', 'GII.17_W', 'GII.17_B'],
                          fontsize=10, fontweight='bold', fontname='Arial')
plt.xticks([1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23], fontsize=10, fontweight='bold', fontname='Arial', rotation=45)
y_fm = ticker.FormatStrFormatter('%.3f')
ax.yaxis.set_major_formatter(y_fm)
ax.yaxis.set_major_locator(ticker.MultipleLocator(0.025))
plt.ylabel('p-distances', fontsize=12, fontweight='bold', fontname='Arial')
plt.xlim(-0, 25)
plt.tight_layout(pad=0)
plt.savefig('Fig.3A.png', dpi=200)
plt.show()













