[Overview]
This readme file provides instructions for Python scripts that were used in a published paper(PMID:34212288).
Ten Python scripts were prepared, which were used to present plots central to the main subject of the paper.
Python scripts contain command-lines for parsing one of the two files (fasta and csv) that are included in the zip file.
The fasta file includes aligned 488 nucleotide sequences (DNA) of ORF2 region C lineages of norovirus.
The csv file includes geographical and seasonal information of isolated region C amplicon of genogroupII (GII).
The scripts are covered by the "Python License (Python-2.0)"



[System requirements]
- Hardware requirements
Python scripts require a current standard computer system.

- Software requirements
Python scripts have been tested on following systems:
Windows 7 professional (64 bit)
Python version (3.6.3) for Windows,

- Module requirements for Python script
csv
re
random
numpy
matplotlib
Bio



[Installation guide]
For the installation of python, please follow the instructions on the web-page (https://wiki.python.org/moin/BeginnersGuide/Download)
In the installation process, please check "Add Python 3.x to PATH".
Typical install time : 30 min
After installation of python, visit (https://biopython.org/wiki/Download) and install Biopython according to "installation instructions" in the web page.
The message "ModuleNotFoundError" in the "Windows PowerShell" after running Python scripts means that one or more of the modules need to be installed.
For the installation of modules, plesase see "https://docs.python.org/3/installing/index.html"
To read or edit Python scripts, please install PyCharm community for Windows "https://www.jetbrains.com/pycharm/download/#section=windows"



[Demo]
Example data are real data that were used in the submitted manuscript
Expected output from 10 python scripts: 

(i) Ten figure files (*.png; Fig.2A, Fig.2D, Fig.3A, Fig.3B, Fig.3C, Fig.3C_lineage_name, Fig.3D, Fig.3E, SFig.1C, and SFig.1D)
(ii) Nine csv files (*.csv; Fig.2A_(group_distance), Fig.3A_(group_distance), Fig.3B_(group_distance), Fig.3B_Data_for_chi_square_analysis, Fig.3C_(random_sampling_data), Fig.3D, Fig.3E, SFig.1C, and SFig.1D)

Run time in a tested computer [Intel Xeon E3-1535M v5 2.90Ghz, 32GB RAM]:
Fig.2A.py (2.2 s)
Fig.2D.py (0.5 s)
Fig.3A.py (7.0 s)
Fig.3B.py (7.3 s)
Fig.3B_data_for_chi_square_analysis (5.3 s)
Fig.3C.py (27.0 s)
Fig.3D.py (0.3 s)
Fig.3E.py (0.3 s)
SFig.1C.py (0.3 s)
and SFig.1D.py (0.3 s)

Expected run time in a normal computer: 
Fig.2A.py (<30 s)
Fig.2D.py (<30 s)
Fig.3A.py (<30 s)
Fig.3B.py (<30 s)
Fig.3B_data_for_chi_square_analysis (<30 s)
Fig.3C.py (<120 s)
Fig.3D.py (<30 s)
Fig.3E.py (<30 s)
SFig.1C.py (<30 s)
and SFig.1D.py (<30 s)



[Instructions for use]
- Unzip the zipfile into appropriate location in your hard drive 
- Run standard program "Windows power shell" in Windows 7
- Using the "Windows power shell", move to the directory of a folder of extracted files
- Input command: 
python Fig.2A.py
python Fig.2D.py
python Fig.3A.py
python Fig.3B.py
python Fig.3B_data_for_chi_square_analysis.py
python Fig.3C.py
python Fig.3D.py
python Fig.3E.py
python SFig.1C.py
python SFig.1D.py

or

py Fig.2A.py
py Fig.2D.py
py Fig.3A.py
py Fig.3B.py
py Fig.3B_data_for_chi_square_analysis.py
py Fig.3C.py
py Fig.3D.py
py Fig.3E.py
py SFig.1C.py
py SFig.1D.py