#!/usr/bin/env python
from Bio import AlignIO
import csv
import re
import matplotlib.pyplot as plt
import random

whole_dic = {}
whole_seq1_name_dic = {}
whole_seq2_name_dic = {}
whole_seq_names = []
dist_list_for_nt_within_seq1_name_GD = []
dist_list_for_nt_within_seq2_name_GD = []
dist_list_for_nt_within_GD = []
length_list = []
seq_name_for_GD = []
nt_seqs_for_GD = []
pattern_two_num = re.compile('GII.\d\d')

#RegionC_lineages
pattern_list_dic0 = {'GII.1': [re.compile('(GII.1)')],
                     'GII.2': [re.compile('(GII.2)')],
                     'GII.3': [re.compile('(GII.3)')],
                     'GII.4': [re.compile('(GII.4)')],
                     'GII.5': [re.compile('(GII.5)')],
                     'GII.6': [re.compile('(GII.6)')],
                     'GII.8': [re.compile('(GII.8)')],
                     'GII.11': [re.compile('(GII.11)')],
                     'GII.12': [re.compile('(GII.12)')],
                     'GII.13': [re.compile('(GII.13)')],
                     'GII.14': [re.compile('(GII.14)')],
                     'GII.17': [re.compile('(GII.17)')],
                     'GII.18': [re.compile('(GII.18)')],
                     'GII.21': [re.compile('(GII.21)')]}
pattern_list_dic1 = {'GII.1': [re.compile('(GII.1)')],
                     'GII.2': [re.compile('(GII.2)')],
                     'GII.3': [re.compile('(GII.3)')],
                     'GII.4': [re.compile('(GII.4)')],
                     'GII.5': [re.compile('(GII.5)')],
                     'GII.6': [re.compile('(GII.6)')],
                     'GII.8': [re.compile('(GII.8)')]}
pattern_list_dic2 = {'GII.11': [re.compile('(GII.11)')],
                     'GII.12': [re.compile('(GII.12)')],
                     'GII.13': [re.compile('(GII.13)')],
                     'GII.14': [re.compile('(GII.14)')],
                     'GII.17': [re.compile('(GII.17)')],
                     'GII.18': [re.compile('(GII.18)')],
                     'GII.21': [re.compile('(GII.21)')]}

def number_of_difference(seq1, seq2):
    p = 0
    pairs = []
    for nucleotide in zip(seq1, seq2):
        if '-' not in nucleotide:
            pairs.append(nucleotide)
    for (x, y) in pairs:
        if x != y:
            p += 1
    return float(p) / len(pairs)

#calculation_of_within_genotype_distances_from_a_fasta_alignment_file
alignment1 = AlignIO.read('alignment_GII_regionC_2014-2020_st_sea.fas', "fasta")
with open('Fig.2A_(group_distance).csv', 'wb') as csv_out_file1:
    csv_filewriter = csv.writer(csv_out_file1)
    for lineage in pattern_list_dic1.keys():
        for record1 in alignment1:
            if len(re.findall(pattern_two_num, str(record1.id))) == 0:
                if len(re.findall(pattern_list_dic1[lineage][0], str(record1.id))) > 0:
                    whole_seq_names.append(record1.id)
                    seq_name_for_GD.append(str(record1.id))
                    nt_seqs_for_GD.append(str(record1.seq))
                else:
                    continue
            if len(dist_list_for_nt_within_GD) == 0:
                dist_list_for_nt_within_GD.append(lineage + '_within_genotype_distances')
                dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'sequence_1')
                dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'sequence_2')
        dict_for_seq_a = dict(zip(seq_name_for_GD, nt_seqs_for_GD))
        for i, sample1 in enumerate(whole_seq_names):
            for j, sample2 in enumerate(whole_seq_names):
                if j >= i:
                    break
                else:
                    seq_a = dict_for_seq_a[sample1]
                    seq_b = dict_for_seq_a[sample2]
                    dist_list_for_nt_within_GD.append(number_of_difference(seq_a, seq_b))
                    dist_list_for_nt_within_seq1_name_GD.append(sample1)
                    dist_list_for_nt_within_seq2_name_GD.append(sample2)
        whole_seq1_name_dic[lineage] = dist_list_for_nt_within_seq1_name_GD
        whole_seq2_name_dic[lineage] = dist_list_for_nt_within_seq2_name_GD
        whole_dic[lineage] = dist_list_for_nt_within_GD
        dist_list_for_nt_within_seq1_name_GD = []
        dist_list_for_nt_within_seq2_name_GD = []
        dist_list_for_nt_within_GD = []
        whole_seq_names = []
        seq_name_for_GD = []
        nt_seqs_for_GD = []
    for lineage in pattern_list_dic2.keys():
        for record1 in alignment1:
            if len(re.findall(pattern_two_num, str(record1.id))) > 0:
                if len(re.findall(pattern_list_dic2[lineage][0], str(record1.id))) > 0:
                    whole_seq_names.append(record1.id)
                    seq_name_for_GD.append(str(record1.id))
                    nt_seqs_for_GD.append(str(record1.seq))
                else:
                    continue
            if len(dist_list_for_nt_within_GD) == 0:
                dist_list_for_nt_within_GD.append(lineage + '_within_genotype_distances')
                dist_list_for_nt_within_seq1_name_GD.append(lineage + '_' + 'species1')
                dist_list_for_nt_within_seq2_name_GD.append(lineage + '_' + 'species2')
        dict_for_seq_a = dict(zip(seq_name_for_GD, nt_seqs_for_GD))
        for i, sample1 in enumerate(whole_seq_names):
            for j, sample2 in enumerate(whole_seq_names):
                if j >= i:
                    break
                else:
                    seq_a = dict_for_seq_a[sample1]
                    seq_b = dict_for_seq_a[sample2]
                    dist_list_for_nt_within_GD.append(number_of_difference(seq_a, seq_b))
                    dist_list_for_nt_within_seq1_name_GD.append(sample1)
                    dist_list_for_nt_within_seq2_name_GD.append(sample2)
        whole_seq1_name_dic[lineage] = dist_list_for_nt_within_seq1_name_GD
        whole_seq2_name_dic[lineage] = dist_list_for_nt_within_seq2_name_GD
        whole_dic[lineage] = dist_list_for_nt_within_GD
        dist_list_for_nt_within_seq1_name_GD = []
        dist_list_for_nt_within_seq2_name_GD = []
        dist_list_for_nt_within_GD = []
        whole_seq_names = []
        seq_name_for_GD = []
        nt_seqs_for_GD = []
    length_list = [len(whole_dic['GII.1']), len(whole_dic['GII.2']), len(whole_dic['GII.3']),
                   len(whole_dic['GII.4']), len(whole_dic['GII.5']), len(whole_dic['GII.6']),
                   len(whole_dic['GII.8']), len(whole_dic['GII.11']),
                   len(whole_dic['GII.12']), len(whole_dic['GII.13']), len(whole_dic['GII.14']),
                   len(whole_dic['GII.17']), len(whole_dic['GII.18']), len(whole_dic['GII.21'])]
    for lineage in pattern_list_dic0:
        while max(length_list) - len(whole_dic[lineage]) > 0:
            whole_dic[lineage].append('-')
            whole_seq1_name_dic[lineage].append('-')
            whole_seq2_name_dic[lineage].append('-')
    a = zip(whole_seq1_name_dic['GII.1'], whole_seq2_name_dic['GII.1'], whole_dic['GII.1'],
            whole_seq1_name_dic['GII.2'], whole_seq2_name_dic['GII.2'], whole_dic['GII.2'],
            whole_seq1_name_dic['GII.3'], whole_seq2_name_dic['GII.3'], whole_dic['GII.3'],
            whole_seq1_name_dic['GII.4'], whole_seq2_name_dic['GII.4'], whole_dic['GII.4'],
            whole_seq1_name_dic['GII.5'], whole_seq2_name_dic['GII.5'], whole_dic['GII.5'],
            whole_seq1_name_dic['GII.6'], whole_seq2_name_dic['GII.6'], whole_dic['GII.6'],
            whole_seq1_name_dic['GII.8'], whole_seq2_name_dic['GII.8'], whole_dic['GII.8'],
            whole_seq1_name_dic['GII.11'], whole_seq2_name_dic['GII.11'], whole_dic['GII.11'],
            whole_seq1_name_dic['GII.12'], whole_seq2_name_dic['GII.12'], whole_dic['GII.12'],
            whole_seq1_name_dic['GII.13'], whole_seq2_name_dic['GII.13'], whole_dic['GII.13'],
            whole_seq1_name_dic['GII.14'], whole_seq2_name_dic['GII.14'], whole_dic['GII.14'],
            whole_seq1_name_dic['GII.17'], whole_seq2_name_dic['GII.17'],whole_dic['GII.17'],
            whole_seq1_name_dic['GII.18'], whole_seq2_name_dic['GII.18'], whole_dic['GII.18'],
            whole_seq1_name_dic['GII.21'], whole_seq2_name_dic['GII.21'], whole_dic['GII.21'])
    for row in a:
        csv_filewriter.writerow(row)

#within_genotype_distance_plot
x = []
xlables = []
x_tick_label = []
plt.figure(figsize=(8, 4), dpi=200)
for lineage in whole_dic.keys():
    xlables.append(lineage)
    x.append(max([a for a in whole_dic[lineage][1:] if a != '-']))
zip_x_xlables = zip(x, xlables)
sorted_x = sorted(zip_x_xlables)
for n, xx in enumerate(sorted_x):
    x_data = [(0.5 + n*2 + random.random()) for a in whole_dic[xx[1]][1:] if a != '-']
    y_data = [a for a in whole_dic[xx[1]][1:] if a != '-']
    plt.scatter(x_data, y_data, color='black', s=0.1, alpha=1)
    x_tick_label.append(xx[1])
for nn, el in enumerate(sorted_x):
    plt.errorbar([nn*2 + 1], [el[0]],
                 yerr=[0],
                 fmt="",
                 linewidth=0,
                 elinewidth=0,
                 ecolor='red',
                 capsize=10,
                 alpha=0.5,
                 capthick=3)
plt.gca().set_xticklabels(x_tick_label, fontsize=12, fontweight='bold', fontname='Arial', rotation=45)
plt.xticks([1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27])
plt.ylabel('p-distance', fontsize=14, fontweight='bold', fontname='Arial')
plt.xlabel('Region C Genotypes of GII', fontsize=14, fontweight='bold', fontname='Arial')
plt.xlim(-1, 29)
plt.tight_layout(pad=0)
plt.savefig('Fig.2A.png', dpi=200)
plt.show()














