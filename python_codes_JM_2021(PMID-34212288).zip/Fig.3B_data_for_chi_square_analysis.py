#!/usr/bin/env python
from Bio import AlignIO
import csv
import matplotlib.pyplot as plt
import random
import re

whole_dic2 = {}
all_samples_a = []
dist_list_for_nt_intra_GD = []
length_list = []
seq_name_for_a_GD = []
nt_seqs_for_a_GD = []
choice_list = []
pattern_sample = re.compile('(\d\d\d\d\d\d\d\d_\D+\w+_\d\d_GII)')
pattern_clone = re.compile('(_\d\d_)')
pattern_site = re.compile('(_\D+\w+_)')
pattern_subgenotype = re.compile('GII.\S+')
study_region_head = ['AM', 'AS', 'DL', 'DM', 'EL', 'EM', 'FL', 'FM', 'GL', 'GM', 'MW']
province_initial_dic = {}

#Connection_between_provinces_and_sites
for element in study_region_head:
    if element == ('AM'):
        province_initial_dic[element] = 'Gg'
    elif element == ('AS'):
        province_initial_dic[element] = 'Gg'
    elif element == ('DL'):
        province_initial_dic[element] = 'NG'
    elif element == ('DM'):
        province_initial_dic[element] = 'NG'
    elif element == ('EL'):
        province_initial_dic[element] = 'SG'
    elif element == ('EM'):
        province_initial_dic[element] = 'SG'
    elif element == ('FL'):
        province_initial_dic[element] = 'SJ'
    elif element == ('FM'):
        province_initial_dic[element] = 'SJ'
    elif element == ('GL'):
        province_initial_dic[element] = 'NJ'
    elif element == ('GM'):
        province_initial_dic[element] = 'NJ'
    elif element == ('MW'):
        province_initial_dic[element] = 'SG'

#RegionC_lineages
list_dic_subg = {'GII.11': ['GII.11a', 'GII.11b', 'GII.11c'],
                 'GII.2': ['GII.2a', 'GII.2b', 'GII.2c'],
                 'GII.3': ['GII.3b', 'GII.3c'],
                 'GII.4': ['GII.4s', 'GII.4ns'],
                 'GII.6': ['GII.6a', 'GII.6b', 'GII.6c'],
                 'GII.17': ['GII.17n', 'GII.17o']}
genotype_dic = {'GII.11': [], 'GII.2': [], 'GII.3': [], 'GII.4': [], 'GII.6': [], 'GII.17': []}

alignment1 = AlignIO.read('alignment_GII_regionC_2014-2020_st_sea.fas', "fasta")
temp_subg_names = []
temp_subg_names2 = []
temp_subg_names3 = []
temp_provinces = []
writing_dic = {'GII.11': [], 'GII.2': [], 'GII.3': [], 'GII.4': [], 'GII.6': [], 'GII.17': []}

#Preparation_of_randomized_sampling_data_in_a_csv_file
with open('Fig.3B_Data_for_chi_square_analysis.csv', 'ab') as csv_out_file1:
    first_row = ['Number_of_sequence_pairs_that_consisted_of_two_different_subgenotypes(10,000 randomized sampling)']
    second_row = ['Genotype\t', 'same_province\t', 'different_provinces\t']
    csv_filewriter = csv.writer(csv_out_file1)
    csv_filewriter.writerow(first_row)
    csv_filewriter.writerow(second_row)
    for record1 in alignment1:
        all_samples_a.append(record1.id)
    for l in all_samples_a:
        for gen in genotype_dic.keys():
            if len(re.findall(gen, str(l))) > 0:
                genotype_dic[gen].append(l)
    for g in list_dic_subg.keys():
        for sg in list_dic_subg[g]:
            for seq_name in genotype_dic[g]:
                if len(re.findall(sg, seq_name)) > 0:
                    temp_subg_names.append(seq_name)
        itr = 10000
        while itr > 0:
            selected_subg_seq_names = random.sample(temp_subg_names, 2)
            for sbn in selected_subg_seq_names:
                if len(re.findall(pattern_subgenotype, sbn)) > 0:
                    temp_subg_names2.append(re.findall(pattern_subgenotype, sbn)[0])
                else:
                    print('error')
                    break
            if len(list(set(temp_subg_names2))) > 1:
                for tsn2 in selected_subg_seq_names:
                    site = re.findall(pattern_site, tsn2)
                    site[0] = re.sub(pattern_clone, '', site[0])
                    site[0] = re.sub('_', '', site[0])
                    for hd in study_region_head:
                        if len(re.findall(hd, site[0])) > 0:
                            temp_provinces.append(province_initial_dic[hd])
                        else:
                            continue
                if len(list(set(temp_provinces))) > 1:
                    writing_dic[g].append('different_provinces')
                else:
                    if g == 'GII.11':
                        print(temp_provinces)
                        print(selected_subg_seq_names)
                    writing_dic[g].append('same_province')
                temp_subg_names2 = []
                temp_provinces = []
                itr = itr - 1
            else:
                temp_subg_names2 = []
        temp_subg_names = []
    csv_filewriter.writerow(
        ['GII.11', writing_dic['GII.11'].count('same_province'), writing_dic['GII.11'].count('different_provinces')])
    csv_filewriter.writerow(
        ['GII.2', writing_dic['GII.2'].count('same_province'), writing_dic['GII.2'].count('different_provinces')])
    csv_filewriter.writerow(
        ['GII.3', writing_dic['GII.3'].count('same_province'), writing_dic['GII.3'].count('different_provinces')])
    csv_filewriter.writerow(
        ['GII.4', writing_dic['GII.4'].count('same_province'), writing_dic['GII.4'].count('different_provinces')])
    csv_filewriter.writerow(
        ['GII.6', writing_dic['GII.6'].count('same_province'), writing_dic['GII.6'].count('different_provinces')])
    csv_filewriter.writerow(
        ['GII.17', writing_dic['GII.17'].count('same_province'), writing_dic['GII.17'].count('different_provinces')])
print('GII.11', writing_dic['GII.11'].count('same_province'), writing_dic['GII.11'].count('different_provinces'))
print('GII.2', writing_dic['GII.2'].count('same_province'), writing_dic['GII.2'].count('different_provinces'))
print('GII.3', writing_dic['GII.3'].count('same_province'), writing_dic['GII.3'].count('different_provinces'))
print('GII.4', writing_dic['GII.4'].count('same_province'), writing_dic['GII.4'].count('different_provinces'))
print('GII.6', writing_dic['GII.6'].count('same_province'), writing_dic['GII.6'].count('different_provinces'))
print('GII.17', writing_dic['GII.17'].count('same_province'), writing_dic['GII.17'].count('different_provinces'))